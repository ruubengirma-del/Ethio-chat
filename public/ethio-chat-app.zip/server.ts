import 'dotenv/config';
import express from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import nodemailer from 'nodemailer';
import { getApps, initializeApp, getApp } from 'firebase-admin/app';
import { getAuth as getAdminAuth } from 'firebase-admin/auth';
import { getFirestore as getAdminFirestore } from 'firebase-admin/firestore';
import { GoogleGenAI, ThinkingLevel, Part } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const MODERATION_EMAIL = 'Ruubengirma@gmail.com';

app.use(express.json({ limit: '15mb' }));

// Read Firebase applet config cleanly
let firebaseProjectId = 'polished-liberty-l4mm2';
let firestoreDatabaseId = 'ai-studio-5aaa3ce5-6e86-4e68-b4fb-8f3678935a86';
let firebaseApiKey = '';
try {
  const cfgPath = path.resolve(__dirname, 'firebase-applet-config.json');
  if (fs.existsSync(cfgPath)) {
    const cfg = JSON.parse(fs.readFileSync(cfgPath, 'utf-8'));
    firebaseProjectId = cfg.projectId || firebaseProjectId;
    firestoreDatabaseId = cfg.firestoreDatabaseId || firestoreDatabaseId;
    firebaseApiKey = cfg.apiKey || '';
  }
} catch {
  // use defaults
}

// Initialize Firebase Admin (uses ADC if available in Cloud Run / GCP environment)
let adminReady = false;
try {
  if (!getApps().length) {
    initializeApp({
      projectId: firebaseProjectId,
    });
  }
  adminReady = true;
} catch (err) {
  console.warn('Firebase Admin init notice:', err instanceof Error ? err.message : err);
}

// In-memory store for Password Reset OTP sessions (hashed code, 10-minute expiry)
interface ResetOtpEntry {
  email: string;
  codeHash: string;
  salt: string;
  expiresAt: number;
  attempts: number;
  verified: boolean;
  resetToken?: string;
}
const resetOtpMap = new Map<string, ResetOtpEntry>();

function hashOtpCode(email: string, code: string, salt: string): string {
  return crypto.createHash('sha256').update(`${email.toLowerCase()}:${code}:${salt}`).digest('hex');
}

function getEmailTransport() {
  const host = process.env.SMTP_HOST || (process.env.GMAIL_USER ? 'smtp.gmail.com' : '');
  const user = process.env.SMTP_USER || process.env.GMAIL_USER || '';
  const pass = process.env.SMTP_PASS || process.env.GMAIL_APP_PASSWORD || '';
  const port = Number(process.env.SMTP_PORT || 587);

  if (host && user && pass) {
    return nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: { user, pass },
    });
  }
  return null;
}

function parseDataUrlParts(dataUrl?: string): { mimeType: string; base64: string; ext: string } | null {
  if (!dataUrl || typeof dataUrl !== 'string') return null;
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return null;
  const mimeType = match[1];
  const ext = mimeType.split('/')[1]?.split(';')[0] || 'bin';
  return { mimeType, base64: match[2], ext };
}

async function sendOutboundEmail(params: {
  to: string;
  subject: string;
  text: string;
  html: string;
  attachments?: Array<{ filename: string; content: Buffer; contentType: string }>;
}): Promise<{ sent: boolean; provider?: string; reason?: string }> {
  const transporter = getEmailTransport();
  const fromAddress = process.env.SMTP_FROM || process.env.SMTP_USER || process.env.GMAIL_USER || 'Ethio Chat <no-reply@ethiochat.app>';

  if (transporter) {
    try {
      await transporter.sendMail({
        from: fromAddress,
        to: params.to,
        subject: params.subject,
        text: params.text,
        html: params.html,
        attachments: params.attachments,
      });
      return { sent: true, provider: 'smtp' };
    } catch (err) {
      console.error('SMTP email send failed:', err);
      return { sent: false, reason: err instanceof Error ? err.message : 'SMTP send failed' };
    }
  }

  const resendKey = process.env.RESEND_API_KEY;
  if (resendKey) {
    try {
      const resp = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${resendKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromAddress,
          to: [params.to],
          subject: params.subject,
          text: params.text,
          html: params.html,
          attachments: params.attachments?.map((a) => ({
            filename: a.filename,
            content: a.content.toString('base64'),
          })),
        }),
      });
      if (resp.ok) {
        return { sent: true, provider: 'resend' };
      }
      const errText = await resp.text();
      return { sent: false, reason: errText || 'Resend API rejected request' };
    } catch (err) {
      return { sent: false, reason: err instanceof Error ? err.message : 'Resend failed' };
    }
  }

  return { sent: false, reason: 'EMAIL_SERVICE_NOT_CONFIGURED' };
}

async function findUserByEmail(normalizedEmail: string): Promise<{ uid: string; email: string } | null> {
  // 1. Try Firebase Admin Auth lookup
  if (adminReady) {
    try {
      const userRecord = await getAdminAuth(getApp()).getUserByEmail(normalizedEmail);
      return { uid: userRecord.uid, email: userRecord.email || normalizedEmail };
    } catch {
      // Fallback to Firestore below
    }

    try {
      const adminDb = getAdminFirestore(getApp(), firestoreDatabaseId);
      const snap = await adminDb.collection('users').where('email', '==', normalizedEmail).limit(1).get();
      if (!snap.empty) {
        const d = snap.docs[0].data();
        return { uid: String(d.userId || snap.docs[0].id), email: normalizedEmail };
      }
    } catch {
      // Fallback to REST query below
    }
  }

  // 2. Fallback: Firestore REST structuredQuery (works cleanly on public user profiles)
  try {
    const queryUrl = `https://firestore.googleapis.com/v1/projects/${firebaseProjectId}/databases/${firestoreDatabaseId}/documents:runQuery${firebaseApiKey ? `?key=${firebaseApiKey}` : ''}`;
    const resp = await fetch(queryUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        structuredQuery: {
          from: [{ collectionId: 'users' }],
          where: {
            fieldFilter: {
              field: { fieldPath: 'email' },
              op: 'EQUAL',
              value: { stringValue: normalizedEmail },
            },
          },
          limit: 1,
        },
      }),
    });
    if (resp.ok) {
      const rows = (await resp.json()) as Array<{ document?: { name: string; fields?: Record<string, { stringValue?: string }> } }>;
      const docMatch = rows.find((r) => r.document);
      if (docMatch?.document) {
        const uid = docMatch.document.fields?.userId?.stringValue || docMatch.document.name.split('/').pop() || '';
        if (uid) return { uid, email: normalizedEmail };
      }
    }
  } catch {
    // ignore
  }
  return null;
}

function getAiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function parseDataUrl(dataUrl?: string): Part | null {
  if (!dataUrl || typeof dataUrl !== 'string') return null;
  const match = dataUrl.match(/^data:([^;]+);base64,(.+)$/);
  if (!match) return null;
  return {
    inlineData: {
      mimeType: match[1],
      data: match[2],
    },
  };
}

function extractStatusAndMessage(err: unknown): { code?: number; status?: string; message: string } {
  const raw = err instanceof Error ? err.message : String(err || '');
  try {
    const parsed = JSON.parse(raw);
    const inner = parsed?.error || parsed;
    return {
      code: typeof inner?.code === 'number' ? inner.code : undefined,
      status: typeof inner?.status === 'string' ? inner.status : undefined,
      message: typeof inner?.message === 'string' ? inner.message : raw,
    };
  } catch {
    return { message: raw };
  }
}

function isRetryableOverload(err: unknown): boolean {
  const info = extractStatusAndMessage(err);
  const msg = info.message.toLowerCase();
  return (
    info.code === 503 ||
    info.code === 429 ||
    info.code === 500 ||
    info.status === 'UNAVAILABLE' ||
    info.status === 'RESOURCE_EXHAUSTED' ||
    msg.includes('503') ||
    msg.includes('high demand') ||
    msg.includes('unavailable') ||
    msg.includes('overloaded') ||
    msg.includes('temporarily') ||
    msg.includes('aborted')
  );
}

app.get('/api/health', (_req, res) => {
  res.json({ ok: true });
});

// 1. Forgot Password Step 1: Send 6-digit verification code to email
app.post('/api/auth/send-reset-code', async (req, res) => {
  const rawEmail = String(req.body?.email || '').trim().toLowerCase();
  if (!rawEmail || !rawEmail.includes('@')) {
    res.status(400).json({ error: 'Please enter a valid email address.' });
    return;
  }

  const foundUser = await findUserByEmail(rawEmail);
  if (!foundUser) {
    res.status(404).json({ error: 'No Ethio Chat account was found with this email address.' });
    return;
  }

  const code = String(crypto.randomInt(100000, 999999));
  const salt = crypto.randomBytes(16).toString('hex');
  const codeHash = hashOtpCode(rawEmail, code, salt);

  resetOtpMap.set(rawEmail, {
    email: rawEmail,
    codeHash,
    salt,
    expiresAt: Date.now() + 10 * 60 * 1000,
    attempts: 0,
    verified: false,
  });

  const emailRes = await sendOutboundEmail({
    to: rawEmail,
    subject: 'Ethio Chat Password Reset Verification Code',
    text: `Your Ethio Chat password reset code is: ${code}\n\nThis code expires in 10 minutes. Do not share this code with anyone.`,
    html: `<div style="font-family:sans-serif;max-width:460px;margin:auto;padding:24px;border-radius:16px;border:1px solid #e2e8f0">
      <h2 style="color:#7560DF;margin-top:0">Ethio Chat Password Reset</h2>
      <p>Enter this 6-digit verification code in the app to set a new password:</p>
      <div style="font-size:32px;font-weight:800;letter-spacing:6px;padding:16px;background:#f4f2ff;color:#503cb3;text-align:center;border-radius:12px">${code}</div>
      <p style="font-size:12px;color:#64748b;margin-top:16px">This code expires in 10 minutes.</p>
    </div>`,
  });

  if (!emailRes.sent) {
    res.status(503).json({
      ok: false,
      code: emailRes.reason || 'EMAIL_SERVICE_NOT_CONFIGURED',
      error:
        emailRes.reason === 'EMAIL_SERVICE_NOT_CONFIGURED'
          ? 'Email delivery (SMTP_HOST/SMTP_USER/SMTP_PASS or RESEND_API_KEY) is not configured on the server yet. Please configure email secrets in Settings > Secrets, or use the Firebase Password Reset Email option below.'
          : emailRes.reason || 'Failed to send verification code email.',
    });
    return;
  }

  res.json({ ok: true, emailSent: true });
});

// 2. Forgot Password Step 2: Strictly verify 6-digit code (rejects wrong codes)
app.post('/api/auth/verify-reset-code', (req, res) => {
  const rawEmail = String(req.body?.email || '').trim().toLowerCase();
  const code = String(req.body?.code || '').trim();

  if (!rawEmail || !code) {
    res.status(400).json({ ok: false, error: 'Email and 6-digit code are required.' });
    return;
  }

  const entry = resetOtpMap.get(rawEmail);
  if (!entry) {
    res.status(400).json({ ok: false, error: 'No verification code was requested for this email. Please send a new code.' });
    return;
  }

  if (Date.now() > entry.expiresAt) {
    resetOtpMap.delete(rawEmail);
    res.status(400).json({ ok: false, error: 'Verification code expired. Please request a new code.' });
    return;
  }

  if (entry.attempts >= 5) {
    resetOtpMap.delete(rawEmail);
    res.status(429).json({ ok: false, error: 'Too many wrong code attempts. Please request a new code.' });
    return;
  }

  const candidateHash = hashOtpCode(rawEmail, code, entry.salt);
  const expectedBuf = Buffer.from(entry.codeHash, 'hex');
  const candidateBuf = Buffer.from(candidateHash, 'hex');
  const matched = expectedBuf.length === candidateBuf.length && crypto.timingSafeEqual(expectedBuf, candidateBuf);

  if (!matched) {
    entry.attempts += 1;
    res.status(400).json({
      ok: false,
      error: 'Incorrect verification code. Please check the code and try again.',
    });
    return;
  }

  const resetToken = crypto.randomBytes(24).toString('hex');
  entry.verified = true;
  entry.resetToken = resetToken;
  res.json({ ok: true, resetToken });
});

// 3. Forgot Password Step 3: Set New Password after valid verification token
app.post('/api/auth/complete-password-reset', async (req, res) => {
  const rawEmail = String(req.body?.email || '').trim().toLowerCase();
  const resetToken = String(req.body?.resetToken || '').trim();
  const newPassword = String(req.body?.newPassword || '');

  if (!rawEmail || !resetToken || newPassword.length < 6) {
    res.status(400).json({ ok: false, error: 'Valid reset session and password (min 6 characters) are required.' });
    return;
  }

  const entry = resetOtpMap.get(rawEmail);
  if (!entry || !entry.verified || entry.resetToken !== resetToken || Date.now() > entry.expiresAt) {
    res.status(400).json({ ok: false, error: 'Reset session expired or invalid. Please verify your code again.' });
    return;
  }

  if (!adminReady) {
    res.status(503).json({ ok: false, error: 'Password update service requires Firebase Admin credentials on the server.' });
    return;
  }

  try {
    const adminAuth = getAdminAuth(getApp());
    const userRecord = await adminAuth.getUserByEmail(rawEmail);
    await adminAuth.updateUser(userRecord.uid, { password: newPassword });
    resetOtpMap.delete(rawEmail);
    res.json({ ok: true });
  } catch (err) {
    console.error('Failed to update Firebase user password:', err);
    res.status(500).json({
      ok: false,
      error: err instanceof Error ? err.message : 'Failed to update password. Please try Firebase reset email.',
    });
  }
});

// 4. Moderation Report / Appeal Email Dispatcher -> Ruubengirma@gmail.com
app.post('/api/moderation/send-email', async (req, res) => {
  const body = req.body as Record<string, unknown>;
  const kind = typeof body.kind === 'string' ? body.kind : 'report';
  const subject =
    typeof body.subject === 'string' && body.subject.trim()
      ? body.subject.trim()
      : `[Ethio Chat] ${kind === 'warning_appeal' ? 'Account Appeal' : 'Post Report'}`;

  let summaryText = typeof body.summaryText === 'string' ? body.summaryText.trim() : '';
  if (!summaryText) {
    if (kind === 'warning_appeal') {
      const reasons = Array.isArray(body.reportedReasons)
        ? body.reportedReasons.map(String).join(', ')
        : 'N/A';
      summaryText = [
        `Account Warning Appeal`,
        `User: ${String(body.displayName || '')} (@${String(body.username || '')})`,
        `Email: ${String(body.email || '')}`,
        `Reports Count: ${String(body.reportsCount || 0)}`,
        `Reported Reasons: ${reasons}`,
        ``,
        `Appeal Message:`,
        `${String(body.appealMessage || '(No text provided, see attachments)')}`,
      ].join('\n');
    } else {
      summaryText = [
        `Post Report`,
        `Reason: ${String(body.reason || 'N/A')}`,
        `Post ID: ${String(body.postId || '')}`,
        `Reported Author: ${String(body.postAuthorDisplayName || '')} (@${String(body.postAuthorUsername || '')})`,
        `Reporter: ${String(body.reporterDisplayName || '')} (@${String(body.reporterUsername || '')})`,
        body.postContentSnippet ? `Post Content: ${String(body.postContentSnippet)}` : '',
        body.details ? `\nAdditional Details:\n${String(body.details)}` : '',
      ]
        .filter(Boolean)
        .join('\n');
    }
  }

  const photoEvidenceUrl = typeof body.photoEvidenceUrl === 'string' ? body.photoEvidenceUrl : undefined;
  const videoEvidenceUrl = typeof body.videoEvidenceUrl === 'string' ? body.videoEvidenceUrl : undefined;

  const attachments: Array<{ filename: string; content: Buffer; contentType: string }> = [];
  const photoPart = parseDataUrlParts(photoEvidenceUrl);
  if (photoPart) {
    attachments.push({
      filename: `${kind}_photo.${photoPart.ext}`,
      content: Buffer.from(photoPart.base64, 'base64'),
      contentType: photoPart.mimeType,
    });
  }
  const videoPart = parseDataUrlParts(videoEvidenceUrl);
  if (videoPart) {
    attachments.push({
      filename: `${kind}_video.${videoPart.ext}`,
      content: Buffer.from(videoPart.base64, 'base64'),
      contentType: videoPart.mimeType,
    });
  }

  const safeHtmlBody = summaryText
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/\n/g, '<br/>');

  const emailRes = await sendOutboundEmail({
    to: MODERATION_EMAIL,
    subject,
    text: summaryText,
    html: `<div style="font-family:sans-serif;max-width:600px;padding:20px;border:1px solid #e2e8f0;border-radius:12px">
      <h2 style="color:#7560DF;margin-top:0">${subject}</h2>
      <p style="line-height:1.6;color:#1e293b">${safeHtmlBody}</p>
      ${attachments.length > 0 ? `<p style="font-size:12px;color:#64748b">Attached evidence files: ${attachments.map((a) => a.filename).join(', ')}</p>` : ''}
    </div>`,
    attachments,
  });

  res.json({
    ok: true,
    recipient: MODERATION_EMAIL,
    emailSent: emailRes.sent,
    reason: emailRes.reason,
  });
});

// RubGPT conversational & multimodal (text + image) AI endpoint
app.post('/api/rubgpt', async (req, res) => {
  const { message, imageUrl, history = [], language = 'en' } = req.body as {
    message?: string;
    imageUrl?: string;
    history?: Array<{ role: 'user' | 'model'; text: string; imageUrl?: string }>;
    language?: 'en' | 'om' | 'am';
  };

  const trimmedMessage = typeof message === 'string' ? message.trim() : '';
  const imagePart = parseDataUrl(imageUrl);

  if (!trimmedMessage && !imagePart) {
    res.status(400).json({ error: 'Please enter a message or attach an image for RubGPT.' });
    return;
  }

  const ai = getAiClient();
  if (!ai) {
    res.status(503).json({
      error:
        language === 'om'
          ? 'Furtuun Gemini API hin qindaa’in jira. Settings > Secrets keessatti mirkaneessaa.'
          : language === 'am'
          ? 'የGemini API ቁልፍ አልተዋቀረም። እባክዎ Settings > Secrets ውስጥ ያረጋግጡ።'
          : 'Gemini API key is not configured yet. Please check Settings > Secrets.',
    });
    return;
  }

  const langHint =
    language === 'om'
      ? 'The user currently has the app set to Afaan Oromo. Respond clearly in Afaan Oromo unless they ask in another language.'
      : language === 'am'
      ? 'The user currently has the app set to Amharic. Respond clearly in Amharic (አማርኛ) unless they ask in another language.'
      : 'Respond clearly and helpfully in the same language the user writes in (English, Afaan Oromo, or Amharic).';

  const systemInstruction = `You are RubGPT, a smart, friendly, and accurate multimodal AI assistant built inside the Ethio Chat app. You can analyze photos/images users upload (read text in images, identify objects, explain problems, translate text from images, answer homework/questions about photos) and answer any text questions in English, Afaan Oromo, or Amharic. Keep answers clear, structured, and warm. ${langHint}`;

  const validHistory = (Array.isArray(history) ? history : [])
    .slice(-14)
    .filter((h) => h && (h.role === 'user' || h.role === 'model') && (typeof h.text === 'string' || typeof h.imageUrl === 'string'));

  let imagesRemainingInHistory = 2;
  const chatHistory = [...validHistory]
    .reverse()
    .map((h) => {
      const parts: Part[] = [];
      if (h.imageUrl && imagesRemainingInHistory > 0) {
        const histImg = parseDataUrl(h.imageUrl);
        if (histImg) {
          parts.push(histImg);
          imagesRemainingInHistory -= 1;
        }
      }
      if (h.text && h.text.trim()) {
        parts.push({ text: h.text });
      }
      if (parts.length === 0) {
        parts.push({ text: ' ' });
      }
      return {
        role: h.role,
        parts,
      };
    })
    .reverse();

  const effectiveText =
    trimmedMessage ||
    (language === 'om'
      ? 'Suuraa kana sirriitti ilaaliitii wanta isa keessa jiru naaf ibsi.'
      : language === 'am'
      ? 'ይህንን ምስል በጥንቃቄ ተመልክተህ በውስጡ ያለውን ግለጽልኝ።'
      : 'Please look closely at this image and describe or explain what is in it.');

  const currentParts: Part[] = [];
  if (imagePart) {
    currentParts.push(imagePart);
  }
  currentParts.push({ text: effectiveText });

  const attempts: Array<{ model: string; useLowThinking: boolean; delayMs: number }> = [
    { model: 'gemini-4-hydrogen', useLowThinking: true, delayMs: 0 },
    { model: 'gemini-3.1-flash-lite', useLowThinking: false, delayMs: 0 },
    { model: 'gemini-3.1-flash-lite', useLowThinking: false, delayMs: 800 },
  ];

  let lastErr: unknown = null;

  for (const attempt of attempts) {
    if (attempt.delayMs > 0) {
      await sleep(attempt.delayMs);
    }

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 14000);

    try {
      const chat = ai.chats.create({
        model: attempt.model,
        history: chatHistory,
        config: {
          systemInstruction,
          abortSignal: controller.signal,
          ...(attempt.useLowThinking
            ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
            : {}),
        },
      });

      const response = await chat.sendMessage({
        message: currentParts,
      });

      clearTimeout(timer);
      res.json({
        reply: response.text || 'I could not generate a response. Please try again.',
      });
      return;
    } catch (err: unknown) {
      clearTimeout(timer);
      lastErr = err;
      console.warn(`RubGPT (${attempt.model}) error:`, extractStatusAndMessage(err).message);
      if (!isRetryableOverload(err)) {
        break;
      }
    }
  }

  console.error('RubGPT API Error after fallback:', lastErr);
  const info = extractStatusAndMessage(lastErr);
  if (isRetryableOverload(lastErr)) {
    res.status(503).json({
      error:
        language === 'om'
          ? 'Tajaajilli AI yeroo ammaa baay’ee muddameera. Mee sekondii muraasa booda irra deebi’aa yaalaa.'
          : language === 'am'
          ? 'የAI አገልግሎቱ በአሁኑ ጊዜ በጣም ተጨናንቋል። እባክዎ ከጥቂት ሰከንዶች በኋላ እንደገና ይሞክሩ።'
          : 'RubGPT is temporarily busy due to high demand. Please wait a few seconds and try again.',
    });
    return;
  }

  res.status(500).json({
    error: info.message || 'Failed to reach RubGPT AI service.',
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const httpServer = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Ethio Chat server running on http://0.0.0.0:${PORT}`);
  });

  // Real-Time WebRTC Signaling WebSocket for Team 10-Seat Live Voice/Video Stage
  interface LivePeerInfo {
    ws: WebSocket;
    teamId: string;
    userId: string;
    username: string;
    displayName: string;
    photoURL?: string;
    seatNumber: number | null;
    micMuted: boolean;
    cameraOn: boolean;
  }

  const teamLiveRooms = new Map<string, Map<string, LivePeerInfo>>();
  const wss = new WebSocketServer({ noServer: true });

  const broadcastToTeamRoom = (teamId: string, payload: Record<string, unknown>, excludeUserId?: string) => {
    const room = teamLiveRooms.get(teamId);
    if (!room) return;
    const raw = JSON.stringify(payload);
    for (const [uid, peer] of room.entries()) {
      if (excludeUserId && uid === excludeUserId) continue;
      if (peer.ws.readyState === WebSocket.OPEN) {
        peer.ws.send(raw);
      }
    }
  };

  const getRoomPeersSnapshot = (teamId: string) => {
    const room = teamLiveRooms.get(teamId);
    if (!room) return [];
    return Array.from(room.values()).map((p) => ({
      userId: p.userId,
      username: p.username,
      displayName: p.displayName,
      photoURL: p.photoURL,
      seatNumber: p.seatNumber,
      micMuted: p.micMuted,
      cameraOn: p.cameraOn,
    }));
  };

  wss.on('connection', (ws: WebSocket) => {
    let joinedTeamId: string | null = null;
    let joinedUserId: string | null = null;

    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(String(data)) as Record<string, any>;
        const type = String(msg.type || '');

        if (type === 'join-room') {
          const teamId = String(msg.teamId || '');
          const userId = String(msg.userId || '');
          if (!teamId || !userId) return;

          joinedTeamId = teamId;
          joinedUserId = userId;

          let room = teamLiveRooms.get(teamId);
          if (!room) {
            room = new Map();
            teamLiveRooms.set(teamId, room);
          }

          const peerInfo: LivePeerInfo = {
            ws,
            teamId,
            userId,
            username: String(msg.username || 'member'),
            displayName: String(msg.displayName || 'Member'),
            photoURL: typeof msg.photoURL === 'string' ? msg.photoURL : undefined,
            seatNumber: typeof msg.seatNumber === 'number' ? msg.seatNumber : null,
            micMuted: Boolean(msg.micMuted),
            cameraOn: Boolean(msg.cameraOn),
          };
          room.set(userId, peerInfo);

          // Send full current peer list back to joining client
          if (ws.readyState === WebSocket.OPEN) {
            ws.send(
              JSON.stringify({
                type: 'room-peers',
                teamId,
                peers: getRoomPeersSnapshot(teamId),
              })
            );
          }

          // Notify all other peers in the room
          broadcastToTeamRoom(
            teamId,
            {
              type: 'peer-joined',
              teamId,
              peer: {
                userId: peerInfo.userId,
                username: peerInfo.username,
                displayName: peerInfo.displayName,
                photoURL: peerInfo.photoURL,
                seatNumber: peerInfo.seatNumber,
                micMuted: peerInfo.micMuted,
                cameraOn: peerInfo.cameraOn,
              },
              peers: getRoomPeersSnapshot(teamId),
            },
            userId
          );
          return;
        }

        if (!joinedTeamId || !joinedUserId) return;
        const room = teamLiveRooms.get(joinedTeamId);
        if (!room) return;

        if (type === 'media-state') {
          const peer = room.get(joinedUserId);
          if (peer) {
            if (msg.seatNumber !== undefined) peer.seatNumber = msg.seatNumber;
            if (typeof msg.micMuted === 'boolean') peer.micMuted = msg.micMuted;
            if (typeof msg.cameraOn === 'boolean') peer.cameraOn = msg.cameraOn;
          }
          broadcastToTeamRoom(joinedTeamId, {
            type: 'media-state',
            teamId: joinedTeamId,
            userId: joinedUserId,
            seatNumber: peer?.seatNumber ?? null,
            micMuted: peer?.micMuted ?? false,
            cameraOn: peer?.cameraOn ?? false,
            peers: getRoomPeersSnapshot(joinedTeamId),
          });
          return;
        }

        if (
          type === 'webrtc-offer' ||
          type === 'webrtc-answer' ||
          type === 'webrtc-ice-candidate'
        ) {
          const toUserId = String(msg.toUserId || '');
          const targetPeer = room.get(toUserId);
          if (targetPeer && targetPeer.ws.readyState === WebSocket.OPEN) {
            targetPeer.ws.send(
              JSON.stringify({
                ...msg,
                fromUserId: joinedUserId,
                teamId: joinedTeamId,
              })
            );
          }
          return;
        }

        if (type === 'leave-room') {
          room.delete(joinedUserId);
          broadcastToTeamRoom(joinedTeamId, {
            type: 'peer-left',
            teamId: joinedTeamId,
            userId: joinedUserId,
            peers: getRoomPeersSnapshot(joinedTeamId),
          });
          if (room.size === 0) teamLiveRooms.delete(joinedTeamId);
          joinedTeamId = null;
          joinedUserId = null;
        }
      } catch {
        // ignore malformed packets
      }
    });

    ws.on('close', () => {
      if (joinedTeamId && joinedUserId) {
        const room = teamLiveRooms.get(joinedTeamId);
        if (room) {
          const current = room.get(joinedUserId);
          if (current && current.ws === ws) {
            room.delete(joinedUserId);
            broadcastToTeamRoom(joinedTeamId, {
              type: 'peer-left',
              teamId: joinedTeamId,
              userId: joinedUserId,
              peers: getRoomPeersSnapshot(joinedTeamId),
            });
            if (room.size === 0) teamLiveRooms.delete(joinedTeamId);
          }
        }
      }
    });
  });

  httpServer.on('upgrade', (request, socket, head) => {
    const reqUrl = request.url || '';
    if (reqUrl.startsWith('/ws/team-live')) {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });
}

startServer();
