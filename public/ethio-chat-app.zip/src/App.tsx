import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { LanguageProvider } from './context/LanguageContext';
import { Header } from './components/common/Header';
import { BottomNav, TabType } from './components/common/BottomNav';
import { FeedView } from './components/feed/FeedView';
import { VideoFeedView } from './components/video/VideoFeedView';
import { ChatListView } from './components/chat/ChatListView';
import { ChatRoomView } from './components/chat/ChatRoomView';
import { CreateGroupModal } from './components/chat/CreateGroupModal';
import { CreateTeamModal } from './components/chat/CreateTeamModal';
import { TeamRoomView } from './components/chat/TeamRoomView';
import { CallModal } from './components/chat/CallModal';
import { ProfileView } from './components/profile/ProfileView';
import { SettingsView } from './components/settings/SettingsView';
import { AuthModal } from './components/auth/AuthModal';
import { UserSearchModal } from './components/common/UserSearchModal';
import { AllUsersView } from './components/common/AllUsersView';
import { NotificationsModal } from './components/common/NotificationsModal';
import { SwitchAccountModal } from './components/settings/SwitchAccountModal';
import { DashboardModal } from './components/settings/DashboardModal';
import { RubGPTModal } from './components/settings/RubGPTModal';
import { BlockedUsersModal } from './components/settings/BlockedUsersModal';
import { DevicesModal } from './components/settings/DevicesModal';
import {
  LastSeenModal,
  TwoStepModal,
  AppLockConfigModal,
  PasscodeOverlay
} from './components/settings/PrivacySecurityModals';
import {
  ChatWallpaperModal,
  FontSizeModal,
  ChatBackupModal,
  FontStyleModal
} from './components/settings/ChatSettingsModals';
import { WarningAppealModal } from './components/profile/WarningAppealModal';
import { ModerationInboxModal } from './components/settings/ModerationInboxModal';
import { ADMIN_MODERATION_EMAIL, getFontStack } from './lib/socialHelpers';
import { db } from './lib/firebase';
import {
  collection,
  query,
  where,
  onSnapshot,
  doc,
  setDoc,
  getDoc
} from 'firebase/firestore';
import { CallSession, ChatParticipant, ChatRoom, Team } from './types';
import { Smartphone, Monitor, AlertTriangle, ShieldAlert, Mail, LogOut } from 'lucide-react';

type ActiveChatState =
  | { type: 'direct'; chatId: string; recipient: ChatParticipant }
  | { type: 'group'; chatId: string; groupRoom: ChatRoom }
  | { type: 'team'; teamId: string; team: Team }
  | null;

const MainAppContent: React.FC = () => {
  const { currentUser, userProfile, loading, isAddingAccount, closeAddAccount, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [activeChat, setActiveChat] = useState<ActiveChatState>(null);
  const [viewingProfileUserId, setViewingProfileUserId] = useState<string | null>(null);
  const [focusedPostId, setFocusedPostId] = useState<string | null>(null);

  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isCreateGroupModalOpen, setIsCreateGroupModalOpen] = useState(false);
  const [isCreateTeamModalOpen, setIsCreateTeamModalOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isSwitchAccountOpen, setIsSwitchAccountOpen] = useState(false);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [isRubGPTOpen, setIsRubGPTOpen] = useState(false);
  const [isBlockedOpen, setIsBlockedOpen] = useState(false);
  const [isDevicesOpen, setIsDevicesOpen] = useState(false);

  const [isLastSeenOpen, setIsLastSeenOpen] = useState(false);
  const [isTwoStepOpen, setIsTwoStepOpen] = useState(false);
  const [isAppLockOpen, setIsAppLockOpen] = useState(false);
  const [isChatWallpaperOpen, setIsChatWallpaperOpen] = useState(false);
  const [isFontSizeOpen, setIsFontSizeOpen] = useState(false);
  const [isFontStyleOpen, setIsFontStyleOpen] = useState(false);
  const [isChatBackupOpen, setIsChatBackupOpen] = useState(false);
  const [isWarningModalOpen, setIsWarningModalOpen] = useState(false);
  const [isModerationInboxOpen, setIsModerationInboxOpen] = useState(false);

  const [isAppLocked, setIsAppLocked] = useState<boolean>(true);
  const [twoStepSessionTick, setTwoStepSessionTick] = useState<number>(0);

  const [activeCall, setActiveCall] = useState<CallSession | null>(null);
  const [deviceFrameMode, setDeviceFrameMode] = useState<boolean>(false);

  // Sync chosen Font Style globally across the entire app
  useEffect(() => {
    const chosen =
      userProfile?.fontStyle ||
      (() => {
        try {
          return localStorage.getItem('ethio_font_style') || undefined;
        } catch {
          return undefined;
        }
      })();
    const stack = getFontStack(chosen);
    document.documentElement.style.setProperty('--app-font', stack);
    document.body.style.fontFamily = stack;
  }, [userProfile?.fontStyle]);

  // Reset App Lock prompt cleanly on user change
  useEffect(() => {
    if (userProfile?.appLockEnabled && (userProfile?.appLockPin || userProfile?.fingerprintLockEnabled)) {
      const unlocked = sessionStorage.getItem(`ethio_applock_ok_${userProfile.userId}`) === 'true';
      setIsAppLocked(!unlocked);
    } else {
      setIsAppLocked(false);
    }
  }, [userProfile?.userId, userProfile?.appLockEnabled, userProfile?.appLockPin, userProfile?.fingerprintLockEnabled]);

  // Support deep links like ?profile=<uid> or ?post=<postId>
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const sharedProfileId = params.get('profile');
    const sharedPostId = params.get('post');

    if (sharedProfileId) {
      setViewingProfileUserId(sharedProfileId);
      setActiveTab('profile');
    } else if (sharedPostId) {
      setFocusedPostId(sharedPostId);
      setActiveTab('home');
    }
  }, []);

  // Listen globally for incoming ringing audio/video calls for the logged-in user
  useEffect(() => {
    if (!currentUser) return;
    const q = query(
      collection(db, 'calls'),
      where('calleeId', '==', currentUser.uid),
      where('status', '==', 'ringing')
    );

    const unsub = onSnapshot(
      q,
      (snapshot) => {
        if (snapshot.empty) return;
        const incoming = snapshot.docs[0].data() as CallSession;
        setActiveCall((prev) => {
          if (prev && prev.callId === incoming.callId) return prev;
          return incoming;
        });
      },
      (err) => console.warn('Incoming call listener error:', err)
    );

    return () => unsub();
  }, [currentUser]);

  const handleStartCall = async (
    target: ChatParticipant,
    callType: 'audio' | 'video',
    chatId: string
  ) => {
    if (!currentUser || !userProfile) return;
    const callId = `call_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const now = new Date().toISOString();
    const session: CallSession = {
      callId,
      chatId,
      callerId: currentUser.uid,
      callerUsername: userProfile.username,
      callerDisplayName: userProfile.displayName,
      ...(userProfile.photoURL ? { callerPhotoURL: userProfile.photoURL } : {}),
      calleeId: target.userId,
      calleeUsername: target.username,
      calleeDisplayName: target.displayName,
      ...(target.photoURL ? { calleePhotoURL: target.photoURL } : {}),
      callType,
      status: 'ringing',
      createdAt: now,
      updatedAt: now,
    };
    await setDoc(doc(db, 'calls', callId), session);
    setActiveCall(session);
  };

  const handleStartChatWithUser = (recipient: ChatParticipant) => {
    if (!currentUser) return;
    const ids = [currentUser.uid, recipient.userId].sort();
    const chatId = `chat_${ids[0]}_${ids[1]}`;
    setActiveChat({ type: 'direct', chatId, recipient });
  };

  const handleSelectGroupChat = (groupRoom: ChatRoom) => {
    setActiveChat({ type: 'group', chatId: groupRoom.chatId, groupRoom });
  };

  const handleSelectTeam = (team: Team) => {
    setActiveChat({ type: 'team', teamId: team.teamId, team });
  };

  const handleNavigateToChatById = async (chatId: string) => {
    try {
      const snap = await getDoc(doc(db, 'chats', chatId));
      if (snap.exists()) {
        const room = snap.data() as ChatRoom;
        if (room.isGroup) {
          setActiveTab('chats');
          setActiveChat({ type: 'group', chatId: room.chatId, groupRoom: room });
          return;
        }
      }
      const teamSnap = await getDoc(doc(db, 'teams', chatId));
      if (teamSnap.exists()) {
        const team = teamSnap.data() as Team;
        setActiveTab('chats');
        setActiveChat({ type: 'team', teamId: team.teamId, team });
        return;
      }
    } catch {
      // ignore
    }
    setActiveTab('chats');
  };

  const handleViewProfile = (userId: string) => {
    setViewingProfileUserId(userId);
    setActiveTab('profile');
    setActiveChat(null);
  };

  const handleClearFocusedPost = () => {
    setFocusedPostId(null);
    const url = new URL(window.location.href);
    url.searchParams.delete('post');
    window.history.replaceState({}, '', url.toString());
  };

  const renderCurrentView = () => {
    if (activeChat) {
      if (activeChat.type === 'team') {
        return (
          <TeamRoomView
            team={activeChat.team}
            onBack={() => setActiveChat(null)}
            onViewProfile={handleViewProfile}
          />
        );
      }

      return (
        <ChatRoomView
          chatId={activeChat.chatId}
          recipient={activeChat.type === 'direct' ? activeChat.recipient : undefined}
          groupRoom={activeChat.type === 'group' ? activeChat.groupRoom : undefined}
          onBack={() => setActiveChat(null)}
          onViewProfile={handleViewProfile}
          onStartCall={handleStartCall}
          onOpenSharedPost={(postId) => {
            setFocusedPostId(postId);
            setActiveTab('home');
            setActiveChat(null);
          }}
        />
      );
    }

    switch (activeTab) {
      case 'home':
        return (
          <FeedView
            onViewProfile={handleViewProfile}
            onStartChatWithUser={handleStartChatWithUser}
            onOpenSearch={() => setIsSearchModalOpen(true)}
            focusedPostId={focusedPostId}
            onClearFocusedPost={handleClearFocusedPost}
          />
        );
      case 'video':
        return (
          <VideoFeedView
            onViewProfile={handleViewProfile}
          />
        );
      case 'chats':
        return (
          <ChatListView
            onSelectChat={(chatId, recipient) => setActiveChat({ type: 'direct', chatId, recipient })}
            onSelectGroupChat={handleSelectGroupChat}
            onSelectTeam={handleSelectTeam}
            onOpenUserSearch={() => setIsSearchModalOpen(true)}
            onOpenCreateGroup={() => setIsCreateGroupModalOpen(true)}
            onOpenCreateTeam={() => setIsCreateTeamModalOpen(true)}
          />
        );
      case 'search':
        return (
          <AllUsersView
            onSelectUserToChat={(recipient) => handleStartChatWithUser(recipient)}
            onViewProfile={handleViewProfile}
          />
        );
      case 'profile':
        return (
          <ProfileView
            userId={viewingProfileUserId || undefined}
            onBack={viewingProfileUserId ? () => setViewingProfileUserId(null) : undefined}
            onStartChat={handleStartChatWithUser}
            onViewProfile={handleViewProfile}
          />
        );
      case 'settings':
        return (
          <SettingsView
            onNavigateToProfile={() => {
              setViewingProfileUserId(null);
              setActiveTab('profile');
            }}
            onOpenCreateGroup={() => setIsCreateGroupModalOpen(true)}
            onOpenSwitchAccount={() => setIsSwitchAccountOpen(true)}
            onOpenDashboard={() => setIsDashboardOpen(true)}
            onOpenRubGPT={() => setIsRubGPTOpen(true)}
            onOpenBlocked={() => setIsBlockedOpen(true)}
            onOpenDevices={() => setIsDevicesOpen(true)}
            onOpenLastSeen={() => setIsLastSeenOpen(true)}
            onOpenTwoStep={() => setIsTwoStepOpen(true)}
            onOpenAppLock={() => setIsAppLockOpen(true)}
            onOpenChatWallpaper={() => setIsChatWallpaperOpen(true)}
            onOpenFontSize={() => setIsFontSizeOpen(true)}
            onOpenFontStyle={() => setIsFontStyleOpen(true)}
            onOpenChatBackup={() => setIsChatBackupOpen(true)}
            onOpenModerationInbox={() => setIsModerationInboxOpen(true)}
          />
        );
      default:
        return (
          <FeedView
            onViewProfile={handleViewProfile}
            onStartChatWithUser={handleStartChatWithUser}
            onOpenSearch={() => setIsSearchModalOpen(true)}
            focusedPostId={focusedPostId}
            onClearFocusedPost={handleClearFocusedPost}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-white dark:bg-[#090714] text-slate-900 dark:text-slate-100 transition-colors flex flex-col items-center">
      {/* Device Frame View Switcher */}
      <div className="w-full bg-white dark:bg-[#120f24] py-1.5 px-4 text-xs border-b border-slate-200 dark:border-purple-950/40 flex items-center justify-between text-slate-600 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#7560DF]" />
          <span className="font-bold text-slate-800 dark:text-slate-200">Ethio Chat</span>
          <span className="text-[10px] hidden sm:inline text-slate-500">Android & iOS Responsive PWA</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setDeviceFrameMode(!deviceFrameMode)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-slate-100 dark:bg-[#1c1836] text-[11px] font-bold text-[#7560DF] shadow-sm hover:opacity-90 transition-opacity"
            title="Toggle Smartphone Frame View"
          >
            {deviceFrameMode ? (
              <>
                <Monitor className="w-3 h-3" />
                <span>Full Web</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3 h-3" />
                <span>Mobile Frame</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Container */}
      <div
        className={`w-full flex-1 flex flex-col transition-all duration-300 ${
          deviceFrameMode
            ? 'max-w-[420px] my-4 rounded-[42px] overflow-hidden shadow-2xl ring-12 ring-slate-800 dark:ring-purple-950/60 bg-white dark:bg-[#0f0d1a] border border-slate-700 min-h-[840px]'
            : 'max-w-2xl bg-white dark:bg-[#0f0d1a] min-h-screen shadow-sm'
        }`}
      >
        <Header
          onOpenSearch={() => setIsSearchModalOpen(true)}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onNavigateToProfile={() => {
            setViewingProfileUserId(null);
            setActiveTab('profile');
            setActiveChat(null);
          }}
        />

        {/* Owner-Only Account Warning Bar (visible strictly to the warned account owner) */}
        {currentUser && userProfile?.warningActive && !userProfile?.accountSuspended && (
          <button
            type="button"
            onClick={() => setIsWarningModalOpen(true)}
            className="w-full px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white text-xs font-extrabold flex items-center justify-center gap-2 transition-colors shadow-sm"
          >
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <span>
              Warning · Account kee irratti report {userProfile.reportsCount || 250}+ jira — Tuqii
              falmadhu
            </span>
          </button>
        )}

        <main className="flex-1 overflow-x-hidden bg-white dark:bg-[#0f0d1a]">
          {renderCurrentView()}
        </main>

        {!activeChat && (
          <BottomNav
            activeTab={activeTab}
            onSelectTab={(tab) => {
              setActiveTab(tab);
              if (tab !== 'profile') {
                setViewingProfileUserId(null);
              }
              setActiveChat(null);
            }}
          />
        )}
      </div>

      {/* Auth Screen Modal (login OR adding an account) */}
      <AuthModal
        isOpen={(!loading && !currentUser) || isAddingAccount}
        onClose={isAddingAccount ? closeAddAccount : undefined}
      />

      {/* Common Notifications Modal */}
      <NotificationsModal
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        onNavigateToProfile={handleViewProfile}
        onNavigateToChat={handleNavigateToChatById}
      />

      {/* Search Modal */}
      <UserSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectUserToChat={(recipient) => handleStartChatWithUser(recipient)}
        onViewProfile={handleViewProfile}
        onSelectPost={(postId) => {
          setFocusedPostId(postId);
          setActiveTab('home');
          setActiveChat(null);
        }}
      />

      {/* Create Group Modal */}
      <CreateGroupModal
        isOpen={isCreateGroupModalOpen}
        onClose={() => setIsCreateGroupModalOpen(false)}
        onGroupCreated={(groupRoom) => {
          setIsCreateGroupModalOpen(false);
          setActiveTab('chats');
          setActiveChat({ type: 'group', chatId: groupRoom.chatId, groupRoom });
        }}
      />

      {/* Create Team Modal */}
      <CreateTeamModal
        isOpen={isCreateTeamModalOpen}
        onClose={() => setIsCreateTeamModalOpen(false)}
        onTeamCreated={(team) => {
          setIsCreateTeamModalOpen(false);
          setActiveTab('chats');
          setActiveChat({ type: 'team', teamId: team.teamId, team });
        }}
      />

      {/* Settings Modals */}
      <SwitchAccountModal
        isOpen={isSwitchAccountOpen}
        onClose={() => setIsSwitchAccountOpen(false)}
      />

      <DashboardModal
        isOpen={isDashboardOpen}
        onClose={() => setIsDashboardOpen(false)}
      />

      <RubGPTModal
        isOpen={isRubGPTOpen}
        onClose={() => setIsRubGPTOpen(false)}
      />

      <BlockedUsersModal
        isOpen={isBlockedOpen}
        onClose={() => setIsBlockedOpen(false)}
      />

      <DevicesModal
        isOpen={isDevicesOpen}
        onClose={() => setIsDevicesOpen(false)}
      />

      <LastSeenModal
        isOpen={isLastSeenOpen}
        onClose={() => setIsLastSeenOpen(false)}
      />

      <TwoStepModal
        isOpen={isTwoStepOpen}
        onClose={() => setIsTwoStepOpen(false)}
      />

      <AppLockConfigModal
        isOpen={isAppLockOpen}
        onClose={() => setIsAppLockOpen(false)}
        onLockNow={() => {
          if (userProfile) {
            sessionStorage.removeItem(`ethio_applock_ok_${userProfile.userId}`);
          }
          setIsAppLocked(true);
        }}
      />

      <ChatWallpaperModal
        isOpen={isChatWallpaperOpen}
        onClose={() => setIsChatWallpaperOpen(false)}
      />

      <FontSizeModal
        isOpen={isFontSizeOpen}
        onClose={() => setIsFontSizeOpen(false)}
      />

      <FontStyleModal
        isOpen={isFontStyleOpen}
        onClose={() => setIsFontStyleOpen(false)}
      />

      <ChatBackupModal
        isOpen={isChatBackupOpen}
        onClose={() => setIsChatBackupOpen(false)}
      />

      {/* Active WebRTC Audio/Video Call Modal */}
      {activeCall && currentUser && (
        <CallModal
          call={activeCall}
          currentUserId={currentUser.uid}
          onClose={() => setActiveCall(null)}
        />
      )}

      {/* Two-Step Verification / App Lock / Fingerprint Security Enforcement */}
      {currentUser && userProfile && (() => {
        void twoStepSessionTick;
        const twoFaOk = sessionStorage.getItem(`ethio_2fa_ok_${currentUser.uid}`) === 'true';
        if (userProfile.twoStepEnabled && userProfile.twoStepPin && !twoFaOk) {
          return (
            <PasscodeOverlay
              mode="2fa"
              expectedPin={userProfile.twoStepPin}
              onUnlock={() => {
                sessionStorage.setItem(`ethio_2fa_ok_${currentUser.uid}`, 'true');
                setTwoStepSessionTick((c) => c + 1);
              }}
              onSignOut={() => signOut()}
            />
          );
        }
        if (
          userProfile.appLockEnabled &&
          (userProfile.appLockPin || userProfile.fingerprintLockEnabled) &&
          isAppLocked
        ) {
          return (
            <PasscodeOverlay
              mode="applock"
              expectedPin={userProfile.appLockPin}
              fingerprintEnabled={Boolean(userProfile.fingerprintLockEnabled)}
              fingerprintCredentialId={userProfile.fingerprintCredentialId}
              onUnlock={() => {
                sessionStorage.setItem(`ethio_applock_ok_${currentUser.uid}`, 'true');
                setIsAppLocked(false);
              }}
              onSignOut={() => signOut()}
            />
          );
        }
        return null;
      })()}

      {/* Owner-Only Warning Appeal Modal & Admin Moderation Inbox */}
      <WarningAppealModal
        isOpen={isWarningModalOpen}
        onClose={() => setIsWarningModalOpen(false)}
      />

      <ModerationInboxModal
        isOpen={isModerationInboxOpen}
        onClose={() => setIsModerationInboxOpen(false)}
      />

      {/* Account Closed / Suspended Overlay (Triggered at 2,500+ unique reports) */}
      {currentUser && userProfile?.accountSuspended && (
        <div className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#16132b] w-full max-w-md rounded-3xl p-6 shadow-2xl border border-rose-200 dark:border-rose-900/60 text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-rose-500/15 text-rose-500 flex items-center justify-center mx-auto">
              <ShieldAlert className="w-9 h-9" />
            </div>
            <div className="space-y-1.5">
              <h2 className="font-extrabold text-xl text-slate-900 dark:text-white">
                Account kee cufameera
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                Account kee irratti namoonni adda addaa {userProfile.reportsCount || 2500}+ ol
                report waan godhaniif ofiin cufameera.
              </p>
            </div>
            <div className="space-y-2 pt-2">
              <a
                href={`mailto:${ADMIN_MODERATION_EMAIL}?subject=${encodeURIComponent(
                  `Account Suspension Appeal (@${userProfile.username})`
                )}`}
                className="w-full py-3 rounded-2xl bg-[#7560DF] hover:bg-[#624ec7] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md shadow-[#7560DF]/25"
              >
                <Mail className="w-4 h-4" />
                <span>Appeal to {ADMIN_MODERATION_EMAIL}</span>
              </a>
              <button
                type="button"
                onClick={() => signOut()}
                className="w-full py-3 rounded-2xl bg-slate-100 dark:bg-[#201c38] hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-bold text-sm flex items-center justify-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                <span>Log Out</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <AuthProvider>
          <MainAppContent />
        </AuthProvider>
      </LanguageProvider>
    </ThemeProvider>
  );
}
