/**
 * Client-side high efficiency media compression utility
 * Compresses images via Canvas API and validates videos to optimize storage.
 */

export async function compressImage(
  file: File | Blob, 
  maxWidth: number = 1080, 
  maxHeight: number = 1080, 
  quality: number = 0.78
): Promise<{ dataUrl: string; sizeBytes: number; originalSize: number }> {
  const originalSize = file.size;

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;

        if (width > maxWidth || height > maxHeight) {
          const ratio = Math.min(maxWidth / width, maxHeight / height);
          width = Math.round(width * ratio);
          height = Math.round(height * ratio);
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas 2D context unavailable'));
          return;
        }

        // Smooth high quality scaling
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, 0, 0, width, height);

        // Convert to WebP if supported or JPEG fallback
        const format = 'image/jpeg';
        const dataUrl = canvas.toDataURL(format, quality);
        const approxSize = Math.round((dataUrl.length * 3) / 4);

        resolve({
          dataUrl,
          sizeBytes: approxSize,
          originalSize
        });
      };
      img.onerror = (err) => reject(new Error('Failed to load image for compression'));
      img.src = event.target?.result as string;
    };
    reader.onerror = (err) => reject(new Error('Failed to read image file'));
    reader.readAsDataURL(file);
  });
}

/**
 * Handle video files: enforce size limit and extract preview thumbnail
 */
export async function processVideoFile(file: File): Promise<{
  dataUrl: string;
  thumbnailUrl: string;
  duration: number;
  sizeBytes: number;
}> {
  return new Promise((resolve, reject) => {
    // Limit raw video input in browser to 15MB for fast playback
    if (file.size > 20 * 1024 * 1024) {
      reject(new Error('Video size exceeds 20MB limit. Please select a shorter video.'));
      return;
    }

    const video = document.createElement('video');
    video.preload = 'metadata';
    const blobUrl = URL.createObjectURL(file);
    video.src = blobUrl;

    video.onloadedmetadata = () => {
      // Seek slightly into video for good thumbnail
      video.currentTime = Math.min(1.0, video.duration / 2);
    };

    video.onseeked = () => {
      const canvas = document.createElement('canvas');
      canvas.width = Math.min(video.videoWidth, 640);
      canvas.height = Math.round((canvas.width / (video.videoWidth || 1)) * video.videoHeight);
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      }
      const thumbnailUrl = canvas.toDataURL('image/jpeg', 0.7);

      const reader = new FileReader();
      reader.onload = (e) => {
        resolve({
          dataUrl: e.target?.result as string,
          thumbnailUrl,
          duration: Math.round(video.duration),
          sizeBytes: file.size
        });
        URL.revokeObjectURL(blobUrl);
      };
      reader.readAsDataURL(file);
    };

    video.onerror = () => {
      URL.revokeObjectURL(blobUrl);
      reject(new Error('Unable to read video file. Format may not be supported by browser.'));
    };
  });
}
