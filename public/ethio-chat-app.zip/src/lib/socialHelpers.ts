import { db } from './firebase';
import { doc, setDoc, updateDoc, increment } from 'firebase/firestore';
import { AppNotification, AudienceVisibility, NotificationType, Post, UserProfile } from '../types';

export function extractMentionedUsers(text: string, allUsers: UserProfile[]): UserProfile[] {
  if (!text) return [];
  const matches = text.match(/@([a-zA-Z0-9_]+)/g);
  if (!matches) return [];
  const handles = new Set(matches.map((m) => m.slice(1).toLowerCase()));
  return allUsers.filter((u) => handles.has(u.username.toLowerCase()));
}

export async function createAppNotification(params: {
  recipientId: string;
  actor: {
    userId: string;
    username: string;
    displayName: string;
    photoURL?: string;
  };
  type: NotificationType;
  postId?: string;
  chatId?: string;
  text?: string;
}): Promise<void> {
  if (!params.recipientId || params.recipientId === params.actor.userId) return;

  const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const payload: AppNotification = {
    notificationId,
    recipientId: params.recipientId,
    actorId: params.actor.userId,
    actorUsername: params.actor.username,
    actorDisplayName: params.actor.displayName,
    ...(params.actor.photoURL ? { actorPhotoURL: params.actor.photoURL } : {}),
    type: params.type,
    ...(params.postId ? { postId: params.postId } : {}),
    ...(params.chatId ? { chatId: params.chatId } : {}),
    ...(params.text ? { text: params.text.slice(0, 300) } : {}),
    read: false,
    createdAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'notifications', notificationId), payload).catch(() => {});
}

const recordedSessionViews = new Set<string>();

export async function recordViewStat(params: {
  targetUserId: string;
  viewerId: string;
  kind: 'profile' | 'post' | 'story';
  targetId: string;
}): Promise<void> {
  if (!params.targetUserId || !params.viewerId) return;
  const sessionKey = `${params.kind}_${params.targetId}_${params.viewerId}`;
  if (recordedSessionViews.has(sessionKey)) return;
  recordedSessionViews.add(sessionKey);

  const statId = `stat_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  await setDoc(doc(db, 'viewStats', statId), {
    statId,
    targetUserId: params.targetUserId,
    viewerId: params.viewerId,
    kind: params.kind,
    targetId: params.targetId,
    createdAt: new Date().toISOString(),
  }).catch(() => {});

  if (params.kind === 'profile') {
    await updateDoc(doc(db, 'users', params.targetUserId), {
      profileViewsCount: increment(1),
    }).catch(() => {});
  } else if (params.kind === 'post') {
    await updateDoc(doc(db, 'posts', params.targetId), {
      viewsCount: increment(1),
    }).catch(() => {});
  } else if (params.kind === 'story') {
    await updateDoc(doc(db, 'stories', params.targetId), {
      viewsCount: increment(1),
    }).catch(() => {});
  }
}

export function isAudienceVisibleToUser(
  item: {
    authorId: string;
    visibility?: AudienceVisibility;
    excludedUserIds?: string[];
    allowedUserIds?: string[];
  },
  viewerId?: string | null
): boolean {
  if (!viewerId) {
    return !item.visibility || item.visibility === 'public';
  }
  if (item.authorId === viewerId) return true;

  const vis = item.visibility || 'public';
  if (vis === 'public') return true;
  if (vis === 'private') return false;
  if (vis === 'close_friends') {
    // Hidden from selected Close Friends list
    return !(item.excludedUserIds || []).includes(viewerId);
  }
  if (vis === 'select_friends') {
    // Visible ONLY to selected friends
    return (item.allowedUserIds || []).includes(viewerId);
  }
  return true;
}

export function getOrCreateDeviceId(): string {
  const KEY = 'ethio_chat_device_id_v1';
  try {
    const existing = localStorage.getItem(KEY);
    if (existing) return existing;
    const created = `dev_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 8)}`;
    localStorage.setItem(KEY, created);
    return created;
  } catch {
    return `dev_${Date.now().toString(36)}`;
  }
}

export function getClientDeviceDetails(): { deviceName: string; platform: string; browser: string } {
  if (typeof navigator === 'undefined') {
    return { deviceName: 'Web Browser', platform: 'Web', browser: 'Unknown' };
  }
  const ua = navigator.userAgent || '';
  let platform = 'Desktop';
  if (/Android/i.test(ua)) platform = 'Android';
  else if (/iPhone|iPad|iPod/i.test(ua)) platform = 'iOS';
  else if (/Windows/i.test(ua)) platform = 'Windows';
  else if (/Mac/i.test(ua)) platform = 'macOS';
  else if (/Linux/i.test(ua)) platform = 'Linux';

  let browser = 'Browser';
  if (/Edg\//i.test(ua)) browser = 'Edge';
  else if (/Chrome\//i.test(ua) && !/Chromium/i.test(ua)) browser = 'Chrome';
  else if (/Safari\//i.test(ua) && !/Chrome/i.test(ua)) browser = 'Safari';
  else if (/Firefox\//i.test(ua)) browser = 'Firefox';

  return {
    deviceName: `${platform} (${browser})`,
    platform,
    browser,
  };
}

export function isUserOnlineNow(user?: Pick<UserProfile, 'hideOnlineStatus' | 'lastSeenAt'> | null): boolean {
  if (!user || user.hideOnlineStatus) return false;
  if (!user.lastSeenAt) return true;
  const diffMs = Date.now() - new Date(user.lastSeenAt).getTime();
  return diffMs >= 0 && diffMs < 3 * 60 * 1000;
}

export function formatLastSeen(isoString?: string): string {
  if (!isoString) return 'Last seen recently';
  try {
    const date = new Date(isoString);
    const diffSec = Math.floor((Date.now() - date.getTime()) / 1000);
    if (diffSec < 120) return 'Online now';
    if (diffSec < 3600) return `Last seen ${Math.floor(diffSec / 60)}m ago`;
    if (diffSec < 86400) {
      return `Last seen today at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    }
    return `Last seen ${date.toLocaleDateString([], { month: 'short', day: 'numeric' })} at ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
  } catch {
    return 'Last seen recently';
  }
}

export interface ChatWallpaperOption {
  id: string;
  label: string;
  className: string;
  previewBg: string;
}

export const CHAT_WALLPAPERS: ChatWallpaperOption[] = [
  {
    id: 'default',
    label: 'Classic Clean',
    className: 'bg-slate-50/40 dark:bg-[#0f0d1a]',
    previewBg: 'linear-gradient(135deg, #f8fafc 0%, #ede9fe 100%)',
  },
  {
    id: 'violet_mist',
    label: 'Rub Violet Mist',
    className: 'bg-gradient-to-br from-[#f3efff] via-[#faf8ff] to-[#e9e2ff] dark:from-[#171230] dark:via-[#110d24] dark:to-[#221947]',
    previewBg: 'linear-gradient(135deg, #7560DF 0%, #B8AAFA 100%)',
  },
  {
    id: 'ethio_sunrise',
    label: 'Ethiopian Sunrise',
    className: 'bg-gradient-to-br from-emerald-50 via-amber-50/70 to-rose-50 dark:from-[#0e2218] dark:via-[#1e1a0e] dark:to-[#271118]',
    previewBg: 'linear-gradient(135deg, #10b981 0%, #f59e0b 50%, #f43f5e 100%)',
  },
  {
    id: 'ocean_breeze',
    label: 'Blue Nile',
    className: 'bg-gradient-to-br from-sky-50 via-cyan-50 to-indigo-50 dark:from-[#0c1c2e] dark:via-[#0f172a] dark:to-[#18163b]',
    previewBg: 'linear-gradient(135deg, #0ea5e9 0%, #6366f1 100%)',
  },
  {
    id: 'midnight_stars',
    label: 'Midnight Slate',
    className: 'bg-gradient-to-b from-slate-200/80 to-slate-100 dark:from-[#090714] dark:to-[#191433]',
    previewBg: 'linear-gradient(135deg, #1e293b 0%, #090714 100%)',
  },
  {
    id: 'soft_rose',
    label: 'Blossom Rose',
    className: 'bg-gradient-to-br from-rose-50 via-pink-50 to-purple-50 dark:from-[#26111e] dark:via-[#1a1026] dark:to-[#130f24]',
    previewBg: 'linear-gradient(135deg, #fb7185 0%, #c084fc 100%)',
  },
];

export const REACTION_EMOJIS_8 = [
  { emoji: '😂', label: 'Joy' },
  { emoji: '❤️', label: 'Love' },
  { emoji: '😢', label: 'Sad' },
  { emoji: '🙏', label: 'Thanks' },
  { emoji: '😮', label: 'Wow' },
  { emoji: '🔥', label: 'Fire' },
  { emoji: '👏', label: 'Clap' },
  { emoji: '🎉', label: 'Celebrate' },
];

export interface FontStyleOption {
  id: string;
  name: string;
  tagline: string;
  stack: string;
}

export const FONT_STYLES: FontStyleOption[] = [
  {
    id: 'plus_jakarta',
    name: 'Plus Jakarta Sans',
    tagline: 'Modern & Crisp (Default)',
    stack: "'Plus Jakarta Sans', 'Inter', 'Noto Sans Ethiopic', system-ui, sans-serif",
  },
  {
    id: 'poppins',
    name: 'Poppins',
    tagline: 'Geometric & Smooth',
    stack: "'Poppins', 'Noto Sans Ethiopic', system-ui, sans-serif",
  },
  {
    id: 'montserrat',
    name: 'Montserrat',
    tagline: 'Bold Contemporary',
    stack: "'Montserrat', 'Noto Sans Ethiopic', system-ui, sans-serif",
  },
  {
    id: 'playfair',
    name: 'Playfair Display',
    tagline: 'Classic Editorial Serif',
    stack: "'Playfair Display', 'Noto Sans Ethiopic', Georgia, serif",
  },
  {
    id: 'lora',
    name: 'Lora',
    tagline: 'Warm Elegant Serif',
    stack: "'Lora', 'Noto Sans Ethiopic', Georgia, serif",
  },
  {
    id: 'nunito',
    name: 'Nunito',
    tagline: 'Friendly Rounded Sans',
    stack: "'Nunito', 'Noto Sans Ethiopic', system-ui, sans-serif",
  },
  {
    id: 'raleway',
    name: 'Raleway',
    tagline: 'Stylish Sleek Lines',
    stack: "'Raleway', 'Noto Sans Ethiopic', system-ui, sans-serif",
  },
  {
    id: 'merriweather',
    name: 'Merriweather',
    tagline: 'Rich Book Serif',
    stack: "'Merriweather', 'Noto Sans Ethiopic', Georgia, serif",
  },
  {
    id: 'quicksand',
    name: 'Quicksand',
    tagline: 'Soft & Airy Rounded',
    stack: "'Quicksand', 'Noto Sans Ethiopic', system-ui, sans-serif",
  },
  {
    id: 'space_grotesk',
    name: 'Space Grotesk',
    tagline: 'Futuristic Tech Display',
    stack: "'Space Grotesk', 'Noto Sans Ethiopic', system-ui, sans-serif",
  },
];

export function getFontStack(fontId?: string): string {
  const found = FONT_STYLES.find((f) => f.id === fontId);
  return found ? found.stack : FONT_STYLES[0].stack;
}

function bufferToBase64Url(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function base64UrlToBuffer(str: string): ArrayBuffer {
  const pad = str.length % 4 === 0 ? '' : '='.repeat(4 - (str.length % 4));
  const b64 = (str + pad).replace(/-/g, '+').replace(/_/g, '/');
  const raw = atob(b64);
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) {
    bytes[i] = raw.charCodeAt(i);
  }
  return bytes.buffer;
}

export async function isPlatformBiometricAvailable(): Promise<boolean> {
  try {
    if (typeof window === 'undefined' || !window.PublicKeyCredential) return false;
    return await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch {
    return false;
  }
}

export async function registerBiometricCredential(
  userId: string,
  username: string
): Promise<{ credentialId: string; nativeWebAuthn: boolean }> {
  try {
    if (typeof window !== 'undefined' && window.PublicKeyCredential && navigator.credentials?.create) {
      const challenge = new Uint8Array(32);
      crypto.getRandomValues(challenge);
      const userBytes = new TextEncoder().encode(userId);
      const cred = (await navigator.credentials.create({
        publicKey: {
          challenge,
          rp: { name: 'Ethio Chat' },
          user: {
            id: userBytes,
            name: username,
            displayName: username,
          },
          pubKeyCredParams: [
            { type: 'public-key', alg: -7 },
            { type: 'public-key', alg: -257 },
          ],
          authenticatorSelection: {
            authenticatorAttachment: 'platform',
            userVerification: 'required',
          },
          timeout: 60000,
        },
      })) as PublicKeyCredential | null;

      if (cred?.rawId) {
        return { credentialId: bufferToBase64Url(cred.rawId), nativeWebAuthn: true };
      }
    }
  } catch (err) {
    console.warn('WebAuthn biometric registration fallback notice:', err);
  }
  return { credentialId: `bio_${userId}`, nativeWebAuthn: false };
}

export async function verifyBiometricCredential(
  credentialId?: string
): Promise<{ verified: boolean; nativeWebAuthn: boolean; error?: string }> {
  if (!credentialId || credentialId.startsWith('bio_')) {
    return { verified: true, nativeWebAuthn: false };
  }
  try {
    if (typeof window !== 'undefined' && window.PublicKeyCredential && navigator.credentials?.get) {
      const challenge = new Uint8Array(32);
      crypto.getRandomValues(challenge);
      const assertion = await navigator.credentials.get({
        publicKey: {
          challenge,
          allowCredentials: [
            {
              id: base64UrlToBuffer(credentialId),
              type: 'public-key',
              transports: ['internal'],
            },
          ],
          userVerification: 'required',
          timeout: 60000,
        },
      });
      if (assertion) {
        return { verified: true, nativeWebAuthn: true };
      }
    }
  } catch (err: any) {
    return {
      verified: false,
      nativeWebAuthn: true,
      error: err?.name === 'NotAllowedError' ? 'Fingerprint scan cancelled or not recognized.' : err?.message,
    };
  }
  return { verified: false, nativeWebAuthn: false, error: 'Fingerprint sensor unavailable.' };
}

export function emailToRegistryId(email: string): string {
  const norm = email.trim().toLowerCase();
  const bytes = new TextEncoder().encode(norm);
  let bin = '';
  for (let i = 0; i < bytes.length; i++) {
    bin += String.fromCharCode(bytes[i]);
  }
  const safe = btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `em_${safe.slice(0, 120)}`;
}

export function normalizeSearchText(input: string): string {
  return (input || '')
    .toLowerCase()
    .trim()
    .replace(/^@+/, '')
    .replace(/[_\-.]+/g, ' ')
    .replace(/\s+/g, ' ');
}

function levenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  const prev = new Array<number>(n + 1);
  const curr = new Array<number>(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    for (let j = 0; j <= n; j++) prev[j] = curr[j];
  }
  return prev[n];
}

function diceBigrams(a: string, b: string): number {
  if (a.length < 2 || b.length < 2) return a === b ? 1 : 0;
  const mapA = new Map<string, number>();
  for (let i = 0; i < a.length - 1; i++) {
    const bg = a.slice(i, i + 2);
    mapA.set(bg, (mapA.get(bg) || 0) + 1);
  }
  let hits = 0;
  for (let i = 0; i < b.length - 1; i++) {
    const bg = b.slice(i, i + 2);
    const count = mapA.get(bg) || 0;
    if (count > 0) {
      hits++;
      mapA.set(bg, count - 1);
    }
  }
  return (2 * hits) / (a.length - 1 + (b.length - 1));
}

function isOrderedSubsequence(needle: string, haystack: string): boolean {
  if (!needle || needle.length > haystack.length) return false;
  let i = 0;
  for (let j = 0; j < haystack.length && i < needle.length; j++) {
    if (needle[i] === haystack[j]) i++;
  }
  return i === needle.length;
}

export function computeStringSimilarity(queryRaw: string, targetRaw: string): number {
  const q = normalizeSearchText(queryRaw);
  const t = normalizeSearchText(targetRaw);
  if (!q || !t) return 0;
  if (t === q) return 1;
  if (t.includes(q)) return 0.92;

  const qCompact = q.replace(/\s+/g, '');
  const tCompact = t.replace(/\s+/g, '');
  if (tCompact.includes(qCompact)) return 0.9;

  let best = 0;
  const qWords = q.split(' ').filter(Boolean);
  const tWords = t.split(' ').filter(Boolean);

  for (const qw of qWords) {
    if (qw.length < 2) continue;
    for (const tw of tWords) {
      if (tw.startsWith(qw)) {
        best = Math.max(best, 0.86);
        continue;
      }
      if (tw.includes(qw)) {
        best = Math.max(best, 0.82);
        continue;
      }
      // Compare against full target word and prefix slice of target word
      const sliced = tw.slice(0, Math.min(tw.length, qw.length + 2));
      const maxLen = Math.max(qw.length, tw.length);
      const levFull = maxLen > 0 ? 1 - levenshteinDistance(qw, tw) / maxLen : 0;
      const maxSliceLen = Math.max(qw.length, sliced.length);
      const levSlice = maxSliceLen > 0 ? 1 - levenshteinDistance(qw, sliced) / maxSliceLen : 0;
      const dice = diceBigrams(qw, tw);
      const subseq = qw.length >= 3 && isOrderedSubsequence(qw, tw) ? 0.58 : 0;
      best = Math.max(best, levFull, levSlice * 0.95, dice * 0.92, subseq);
    }
  }

  // Also compare compact whole strings
  const maxC = Math.max(qCompact.length, tCompact.length);
  if (maxC > 0 && Math.abs(qCompact.length - tCompact.length) <= Math.max(4, qCompact.length)) {
    const levCompact = 1 - levenshteinDistance(qCompact, tCompact) / maxC;
    best = Math.max(best, levCompact);
  }
  if (qCompact.length >= 2 && tCompact.length >= 2) {
    best = Math.max(best, diceBigrams(qCompact, tCompact) * 0.9);
  }

  return best;
}

export function searchUsersWithFallback(
  queryText: string,
  users: UserProfile[]
): { exactMatches: UserProfile[]; similarMatches: UserProfile[] } {
  const clean = normalizeSearchText(queryText);
  const compact = clean.replace(/\s+/g, '');
  if (!clean) {
    return { exactMatches: users, similarMatches: [] };
  }

  const exactMatches = users.filter((u) => {
    const uname = normalizeSearchText(u.username);
    const dname = normalizeSearchText(u.displayName);
    const bio = normalizeSearchText(u.bio || '');
    return (
      uname.includes(clean) ||
      uname.replace(/\s+/g, '').includes(compact) ||
      dname.includes(clean) ||
      dname.replace(/\s+/g, '').includes(compact) ||
      bio.includes(clean)
    );
  });

  if (exactMatches.length > 0) {
    exactMatches.sort((a, b) => {
      const aStarts =
        normalizeSearchText(a.username).startsWith(clean) ||
        normalizeSearchText(a.displayName).startsWith(clean)
          ? 1
          : 0;
      const bStarts =
        normalizeSearchText(b.username).startsWith(clean) ||
        normalizeSearchText(b.displayName).startsWith(clean)
          ? 1
          : 0;
      return bStarts - aStarts;
    });
    return { exactMatches, similarMatches: [] };
  }

  const scored = users
    .map((u) => {
      const score = Math.max(
        computeStringSimilarity(clean, u.username),
        computeStringSimilarity(clean, u.displayName),
        computeStringSimilarity(clean, u.bio || '') * 0.85
      );
      return { user: u, score };
    })
    .filter((entry) => entry.score >= 0.42)
    .sort((a, b) => b.score - a.score)
    .slice(0, 15)
    .map((entry) => entry.user);

  return { exactMatches: [], similarMatches: scored };
}

export function searchPostsWithFallback(
  queryText: string,
  posts: Post[]
): { exactMatches: Post[]; similarMatches: Post[] } {
  const clean = normalizeSearchText(queryText);
  const compact = clean.replace(/\s+/g, '');
  if (!clean) {
    return { exactMatches: [], similarMatches: [] };
  }

  const qWords = clean.split(' ').filter(Boolean);
  const exactMatches = posts.filter((p) => {
    const content = normalizeSearchText(p.content || '');
    const authorName = normalizeSearchText(p.authorDisplayName || '');
    const authorHandle = normalizeSearchText(p.authorUsername || '');
    const combined = `${content} ${authorName} ${authorHandle}`;
    if (
      content.includes(clean) ||
      authorName.includes(clean) ||
      authorHandle.includes(clean) ||
      authorHandle.replace(/\s+/g, '').includes(compact)
    ) {
      return true;
    }
    return qWords.length > 1 && qWords.every((w) => combined.includes(w));
  });

  if (exactMatches.length > 0) {
    return { exactMatches, similarMatches: [] };
  }

  const scored = posts
    .map((p) => {
      const score = Math.max(
        computeStringSimilarity(clean, p.content || ''),
        computeStringSimilarity(clean, p.authorDisplayName || ''),
        computeStringSimilarity(clean, p.authorUsername || '')
      );
      return { post: p, score };
    })
    .filter((entry) => entry.score >= 0.42)
    .sort((a, b) => b.score - a.score)
    .slice(0, 15)
    .map((entry) => entry.post);

  return { exactMatches: [], similarMatches: scored };
}

export const ADMIN_MODERATION_EMAIL = 'Ruubengirma@gmail.com';

export const REPORT_REASONS = [
  'Seera app kana cabseera',
  'Waan inni gad lakkise kun seera cabsa ykn aadaa cabsa',
  'Scamer dha nama gowwomsa',
  'Account fake dha kan namaan fayyadama',
  'Ijoollee umurii 17 gadii ni miidha',
] as const;

export function getCurrentMonthKey(): string {
  const now = new Date();
  const y = now.getUTCFullYear();
  const m = String(now.getUTCMonth() + 1).padStart(2, '0');
  return `${y}-${m}`;
}

export async function saveMediaToDevice(
  url: string,
  filename: string,
  mimeType?: string
): Promise<'shared' | 'downloaded'> {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    const resolvedType = mimeType || blob.type || 'application/octet-stream';
    const file = new File([blob], filename, { type: resolvedType });

    const isTouchDevice =
      typeof navigator !== 'undefined' &&
      /Android|iPhone|iPad|iPod/i.test(navigator.userAgent || '');

    if (
      isTouchDevice &&
      typeof navigator.share === 'function' &&
      typeof navigator.canShare === 'function' &&
      navigator.canShare({ files: [file] })
    ) {
      try {
        await navigator.share({
          files: [file],
          title: filename,
        });
        return 'shared';
      } catch (shareErr: any) {
        if (shareErr?.name === 'AbortError') {
          return 'shared';
        }
      }
    }

    const blobUrl = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 6000);
    return 'downloaded';
  } catch {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    return 'downloaded';
  }
}

export function saveTextToDevice(text: string, filename: string): void {
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const blobUrl = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = blobUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(blobUrl), 6000);
}



