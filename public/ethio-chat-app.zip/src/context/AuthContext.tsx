import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut as firebaseSignOut, 
  updateProfile, 
  updateEmail, 
  updatePassword,
  signInWithPopup,
  GoogleAuthProvider,
  sendPasswordResetEmail,
  deleteUser,
  reauthenticateWithPopup,
  User as FirebaseUser
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  getDocs,
  setDoc, 
  updateDoc, 
  deleteDoc, 
  increment, 
  onSnapshot,
  collection,
  query,
  where
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { 
  UserProfile, 
  FollowRecord, 
  BlockedUserRecord, 
  DeviceSession, 
  AppNotification, 
  SavedAccount 
} from '../types';
import { 
  createAppNotification, 
  emailToRegistryId,
  getClientDeviceDetails, 
  getOrCreateDeviceId 
} from '../lib/socialHelpers';

const SAVED_ACCOUNTS_KEY = 'ethio_chat_saved_accounts_v1';
const LOCAL_SESSION_KEY = 'ethio_chat_local_session';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  loading: boolean;
  signIn: (email: string, pass: string) => Promise<void>;
  signUp: (username: string, email: string, pass: string, displayName?: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  requestPasswordResetCode: (email: string) => Promise<{ ok: boolean; emailSent?: boolean }>;
  verifyPasswordResetCode: (email: string, code: string) => Promise<string>;
  completePasswordResetWithToken: (email: string, resetToken: string, newPassword: string) => Promise<void>;
  signOut: () => Promise<void>;
  deleteAccount: () => Promise<void>;
  updateUserProfileData: (updates: {
    displayName?: string;
    photoURL?: string;
    coverURL?: string;
    bio?: string;
    email?: string;
    newPassword?: string;
    closeFriendsExcludedIds?: string[];
    selectedFriendIds?: string[];
    lastSeenVisibility?: 'everyone' | 'followers' | 'nobody';
    readReceiptsEnabled?: boolean;
    twoStepEnabled?: boolean;
    twoStepPin?: string;
    appLockEnabled?: boolean;
    appLockPin?: string;
    fontStyle?: string;
    fingerprintLockEnabled?: boolean;
    fingerprintCredentialId?: string;
    chatWallpaper?: string;
    chatFontSize?: 'small' | 'medium' | 'large';
    messageReactionsEnabled?: boolean;
    autoDownloadMedia?: boolean;
    lastBackupAt?: string;
  }) => Promise<void>;
  toggleHideOnlineStatus: () => Promise<void>;
  followUser: (targetUserId: string) => Promise<void>;
  unfollowUser: (targetUserId: string) => Promise<void>;
  followingIds: Set<string>;
  followerIds: Set<string>;
  allUsers: UserProfile[];
  // Switch / Add Account
  savedAccounts: SavedAccount[];
  isAddingAccount: boolean;
  openAddAccount: () => void;
  closeAddAccount: () => void;
  switchSavedAccount: (account: SavedAccount) => Promise<void>;
  removeSavedAccount: (uid: string) => void;
  // Block System
  blockedUsers: BlockedUserRecord[];
  blockedIds: Set<string>;
  blockUser: (target: { userId: string; username: string; displayName: string; photoURL?: string }) => Promise<void>;
  unblockUser: (targetUserId: string) => Promise<void>;
  // Devices System
  devices: DeviceSession[];
  currentDeviceId: string;
  removeDevice: (deviceId: string) => Promise<void>;
  // Notifications
  notifications: AppNotification[];
  unreadNotificationsCount: number;
  markNotificationRead: (notificationId: string) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

function readSavedAccounts(): SavedAccount[] {
  try {
    const raw = localStorage.getItem(SAVED_ACCOUNTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function persistSavedAccount(account: SavedAccount): SavedAccount[] {
  const existing = readSavedAccounts();
  const filtered = existing.filter((a) => a.uid !== account.uid);
  const updated = [account, ...filtered].slice(0, 10);
  try {
    localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
  return updated;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_SESSION_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [followingIds, setFollowingIds] = useState<Set<string>>(new Set());
  const [followerIds, setFollowerIds] = useState<Set<string>>(new Set());
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);

  const [savedAccounts, setSavedAccounts] = useState<SavedAccount[]>(() => readSavedAccounts());
  const [isAddingAccount, setIsAddingAccount] = useState(false);

  const [blockedUsers, setBlockedUsers] = useState<BlockedUserRecord[]>([]);
  const [blockedIds, setBlockedIds] = useState<Set<string>>(new Set());

  const [devices, setDevices] = useState<DeviceSession[]>([]);
  const currentDeviceId = getOrCreateDeviceId();

  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // Listen to Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        setCurrentUser(user);
        localStorage.removeItem(LOCAL_SESSION_KEY);
      } else {
        const local = localStorage.getItem(LOCAL_SESSION_KEY);
        if (local) {
          try {
            setCurrentUser(JSON.parse(local));
          } catch {
            setCurrentUser(null);
          }
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen to User Profile when currentUser changes
  useEffect(() => {
    if (!currentUser) {
      setUserProfile(null);
      setFollowingIds(new Set());
      setFollowerIds(new Set());
      setBlockedUsers([]);
      setBlockedIds(new Set());
      setDevices([]);
      setNotifications([]);
      return;
    }

    const userDocRef = doc(db, 'users', currentUser.uid);
    const unsubProfile = onSnapshot(userDocRef, async (snap) => {
      if (snap.exists()) {
        const prof = snap.data() as UserProfile;
        setUserProfile(prof);
        // Auto-lift Warning if user reached 400,000+ post shares within the current month
        const nowMonth = `${new Date().getUTCFullYear()}-${String(new Date().getUTCMonth() + 1).padStart(2, '0')}`;
        if (
          prof.warningActive &&
          prof.monthlySharesMonth === nowMonth &&
          (prof.monthlySharesCount || 0) >= 400000
        ) {
          updateDoc(userDocRef, {
            warningActive: false,
            warningClearedReason: '400k_monthly_shares',
            updatedAt: new Date().toISOString(),
          }).catch(() => {});
        }
        const sessionType: 'local' | 'firebase' = localStorage.getItem(LOCAL_SESSION_KEY) ? 'local' : 'firebase';
        setSavedAccounts(
          persistSavedAccount({
            uid: prof.userId,
            email: prof.email,
            username: prof.username,
            displayName: prof.displayName,
            photoURL: prof.photoURL,
            sessionType,
          })
        );
      } else {
        const username = currentUser.email?.split('@')[0] || `user_${currentUser.uid.slice(0, 5)}`;
        const newProfile: UserProfile = {
          userId: currentUser.uid,
          username,
          displayName: currentUser.displayName || username || 'Ethio User',
          email: currentUser.email || '',
          photoURL: currentUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`,
          bio: 'Hello! I am using Ethio Chat ✨',
          followersCount: 0,
          followingCount: 0,
          hideOnlineStatus: false,
          profileViewsCount: 0,
          createdAt: new Date().toISOString()
        };
        try {
          await setDoc(userDocRef, newProfile);
          setUserProfile(newProfile);
        } catch (err) {
          console.warn('Failed to initialize user document:', err);
        }
      }
    }, (error) => {
      console.warn('Profile listener notice:', error);
    });

    return () => unsubProfile();
  }, [currentUser]);

  // Register & listen to logged-in devices
  useEffect(() => {
    if (!currentUser) return;

    const details = getClientDeviceDetails();
    const deviceRef = doc(db, 'users', currentUser.uid, 'devices', currentDeviceId);
    const now = new Date().toISOString();
    let registeredOnce = false;

    setDoc(
      deviceRef,
      {
        deviceId: currentDeviceId,
        userId: currentUser.uid,
        deviceName: details.deviceName,
        platform: details.platform,
        browser: details.browser,
        lastActiveAt: now,
        createdAt: now,
      },
      { merge: true }
    )
      .then(() => {
        registeredOnce = true;
      })
      .catch(() => {});

    const unsubDevices = onSnapshot(
      collection(db, 'users', currentUser.uid, 'devices'),
      (snapshot) => {
        const list: DeviceSession[] = [];
        snapshot.forEach((d) => list.push(d.data() as DeviceSession));
        list.sort((a, b) => new Date(b.lastActiveAt).getTime() - new Date(a.lastActiveAt).getTime());
        setDevices(list);

        // If this device was remotely removed after registration, sign out locally
        if (registeredOnce && !list.some((d) => d.deviceId === currentDeviceId)) {
          localStorage.removeItem(LOCAL_SESSION_KEY);
          firebaseSignOut(auth).catch(() => {});
          setCurrentUser(null);
          setUserProfile(null);
        }
      },
      (err) => console.warn('Devices listener error:', err)
    );

    return () => unsubDevices();
  }, [currentUser, currentDeviceId]);

  // Track real-time Last Seen presence heartbeat
  useEffect(() => {
    if (!currentUser) return;
    const pingLastSeen = () => {
      if (document.visibilityState === 'hidden') return;
      updateDoc(doc(db, 'users', currentUser.uid), {
        lastSeenAt: new Date().toISOString(),
      }).catch(() => {});
    };

    pingLastSeen();
    const interval = setInterval(pingLastSeen, 60000);
    window.addEventListener('focus', pingLastSeen);
    document.addEventListener('visibilitychange', pingLastSeen);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', pingLastSeen);
      document.removeEventListener('visibilitychange', pingLastSeen);
    };
  }, [currentUser]);

  // Listen to blocked users
  useEffect(() => {
    if (!currentUser) return;
    const unsub = onSnapshot(
      collection(db, 'users', currentUser.uid, 'blocked'),
      (snapshot) => {
        const list: BlockedUserRecord[] = [];
        const ids = new Set<string>();
        snapshot.forEach((d) => {
          const item = d.data() as BlockedUserRecord;
          list.push(item);
          ids.add(item.blockedUserId);
        });
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setBlockedUsers(list);
        setBlockedIds(ids);
      },
      (err) => console.warn('Blocked users listener error:', err)
    );
    return () => unsub();
  }, [currentUser]);

  // Listen to notifications for current user
  useEffect(() => {
    if (!currentUser) return;
    const q = query(
      collection(db, 'notifications'),
      where('recipientId', '==', currentUser.uid)
    );
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const list: AppNotification[] = [];
        snapshot.forEach((d) => list.push(d.data() as AppNotification));
        list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        setNotifications(list);
      },
      (err) => console.warn('Notifications listener error:', err)
    );
    return () => unsub();
  }, [currentUser]);

  // Listen to following and followers when logged in
  useEffect(() => {
    if (!currentUser) return;

    const qFollowing = query(collection(db, 'follows'), where('followerId', '==', currentUser.uid));
    const unsubFollowing = onSnapshot(qFollowing, (snapshot) => {
      const set = new Set<string>();
      snapshot.forEach(d => {
        const data = d.data() as FollowRecord;
        set.add(data.followingId);
      });
      setFollowingIds(set);
    }, (err) => {
      console.warn('Following listener error:', err);
    });

    const qFollowers = query(collection(db, 'follows'), where('followingId', '==', currentUser.uid));
    const unsubFollowers = onSnapshot(qFollowers, (snapshot) => {
      const set = new Set<string>();
      snapshot.forEach(d => {
        const data = d.data() as FollowRecord;
        set.add(data.followerId);
      });
      setFollowerIds(set);
    }, (err) => {
      console.warn('Followers listener error:', err);
    });

    return () => {
      unsubFollowing();
      unsubFollowers();
    };
  }, [currentUser]);

  // Listen to all users for search, group invites & mentions
  useEffect(() => {
    if (!currentUser) return;

    const unsub = onSnapshot(collection(db, 'users'), (snapshot) => {
      const list: UserProfile[] = [];
      snapshot.forEach(d => {
        list.push(d.data() as UserProfile);
      });
      setAllUsers(list);
    }, (err) => {
      console.warn('All users listener error:', err);
    });
    return () => unsub();
  }, [currentUser]);

  const ensureEmailAvailableForUid = async (rawEmail: string, excludeUid?: string) => {
    const normalizedEmail = rawEmail.trim().toLowerCase();
    if (!normalizedEmail) throw new Error('Please enter a valid email address.');

    // 1. Check dedicated emailLocks registry
    const lockKey = emailToRegistryId(normalizedEmail);
    try {
      const lockSnap = await getDoc(doc(db, 'emailLocks', lockKey));
      if (lockSnap.exists()) {
        const ownerUid = lockSnap.data()?.userId;
        if (!excludeUid || ownerUid !== excludeUid) {
          throw new Error('EMAIL_ALREADY_IN_USE');
        }
      }
    } catch (err: any) {
      if (err?.message === 'EMAIL_ALREADY_IN_USE') throw err;
    }

    // 2. Check all user profiles case-insensitively (catches legacy accounts too)
    try {
      const usersSnap = await getDocs(collection(db, 'users'));
      for (const d of usersSnap.docs) {
        const data = d.data() as UserProfile;
        if (
          data.email &&
          data.email.trim().toLowerCase() === normalizedEmail &&
          (!excludeUid || data.userId !== excludeUid)
        ) {
          throw new Error('EMAIL_ALREADY_IN_USE');
        }
      }
    } catch (err: any) {
      if (err?.message === 'EMAIL_ALREADY_IN_USE') throw err;
    }
  };

  const claimEmailLock = async (rawEmail: string, userId: string) => {
    const normalizedEmail = rawEmail.trim().toLowerCase();
    if (!normalizedEmail || !userId) return;
    const emailKey = emailToRegistryId(normalizedEmail);
    const ref = doc(db, 'emailLocks', emailKey);
    const existing = await getDoc(ref).catch(() => null);
    if (existing && existing.exists()) {
      if (existing.data()?.userId !== userId) {
        throw new Error('EMAIL_ALREADY_IN_USE');
      }
      return;
    }
    await setDoc(ref, {
      emailKey,
      email: normalizedEmail,
      userId,
      createdAt: new Date().toISOString(),
    }).catch(() => {});
  };

  // Sign In with email & password
  const signIn = async (email: string, pass: string) => {
    const normalizedEmail = email.trim().toLowerCase();
    try {
      const cred = await signInWithEmailAndPassword(auth, normalizedEmail, pass);
      setIsAddingAccount(false);
      await claimEmailLock(normalizedEmail, cred.user.uid).catch(() => {});
    } catch (error: any) {
      if (error?.code === 'auth/operation-not-allowed' || error?.message?.includes('operation-not-allowed')) {
        // Look up the exact single account registered for this email
        const usersSnap = await getDocs(collection(db, 'users'));
        const matched = usersSnap.docs
          .map((d) => d.data() as UserProfile)
          .find((u) => u.email && u.email.trim().toLowerCase() === normalizedEmail);

        if (!matched) {
          throw new Error('No account found for this email. Please Sign Up to create one account.');
        }

        const localUser = {
          uid: matched.userId,
          email: matched.email,
          displayName: matched.displayName,
          photoURL: matched.photoURL || ''
        } as unknown as FirebaseUser;

        setCurrentUser(localUser);
        localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(localUser));
        setUserProfile(matched);
        setIsAddingAccount(false);
        await claimEmailLock(normalizedEmail, matched.userId).catch(() => {});
        return;
      }
      throw error;
    }
  };

  // Sign Up with username, email, password (strictly 1 email = 1 account)
  const signUp = async (username: string, email: string, pass: string, displayName?: string) => {
    const normalizedEmail = email.trim().toLowerCase();
    const cleanUsername = username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    const finalDisplayName = displayName?.trim() || cleanUsername;

    // Enforce 1 email = 1 account before creating anything
    await ensureEmailAvailableForUid(normalizedEmail);

    try {
      const res = await createUserWithEmailAndPassword(auth, normalizedEmail, pass);
      await updateProfile(res.user, {
        displayName: finalDisplayName
      });

      const profile: UserProfile = {
        userId: res.user.uid,
        username: cleanUsername,
        displayName: finalDisplayName,
        email: normalizedEmail,
        photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}`,
        bio: 'Just joined Ethio Chat! 🇪🇹✨',
        followersCount: 0,
        followingCount: 0,
        hideOnlineStatus: false,
        profileViewsCount: 0,
        createdAt: new Date().toISOString()
      };

      await claimEmailLock(normalizedEmail, res.user.uid);
      await setDoc(doc(db, 'users', res.user.uid), profile);
      setUserProfile(profile);
      setIsAddingAccount(false);
    } catch (error: any) {
      if (error?.code === 'auth/operation-not-allowed' || error?.message?.includes('operation-not-allowed')) {
        // Re-verify email is still unclaimed right before creating fallback account
        await ensureEmailAvailableForUid(normalizedEmail);

        const uid = `usr_${cleanUsername}_${Date.now().toString(36)}`;
        const localUser = {
          uid,
          email: normalizedEmail,
          displayName: finalDisplayName,
          photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}`
        } as unknown as FirebaseUser;

        const profile: UserProfile = {
          userId: uid,
          username: cleanUsername,
          displayName: finalDisplayName,
          email: normalizedEmail,
          photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}`,
          bio: 'Just joined Ethio Chat! 🇪🇹✨',
          followersCount: 0,
          followingCount: 0,
          hideOnlineStatus: false,
          profileViewsCount: 0,
          createdAt: new Date().toISOString()
        };

        await claimEmailLock(normalizedEmail, uid);
        await setDoc(doc(db, 'users', uid), profile);
        setCurrentUser(localUser);
        localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(localUser));
        setUserProfile(profile);
        setIsAddingAccount(false);
        return;
      }
      throw error;
    }
  };

  // Google Sign In (strictly 1 email = 1 account)
  const signInWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      const res = await signInWithPopup(auth, provider);
      const normalizedEmail = (res.user.email || '').trim().toLowerCase();
      const userDocRef = doc(db, 'users', res.user.uid);
      const snap = await getDoc(userDocRef);

      if (!snap.exists()) {
        if (normalizedEmail) {
          try {
            await ensureEmailAvailableForUid(normalizedEmail, res.user.uid);
          } catch (dupErr) {
            await firebaseSignOut(auth).catch(() => {});
            throw dupErr;
          }
        }
        const username = (normalizedEmail.split('@')[0] || `user_${res.user.uid.slice(0, 6)}`).toLowerCase().replace(/[^a-z0-9_]/g, '');
        const profile: UserProfile = {
          userId: res.user.uid,
          username,
          displayName: res.user.displayName || username,
          email: normalizedEmail,
          photoURL: res.user.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`,
          bio: 'Connecting on Ethio Chat 🚀',
          followersCount: 0,
          followingCount: 0,
          hideOnlineStatus: false,
          profileViewsCount: 0,
          createdAt: new Date().toISOString()
        };
        if (normalizedEmail) {
          await claimEmailLock(normalizedEmail, res.user.uid);
        }
        await setDoc(userDocRef, profile);
      } else if (normalizedEmail) {
        await claimEmailLock(normalizedEmail, res.user.uid).catch(() => {});
      }

      localStorage.removeItem(LOCAL_SESSION_KEY);
      setIsAddingAccount(false);
    } catch (error) {
      console.warn('Google sign-in notice:', error);
      throw error;
    }
  };

  const resetPassword = async (email: string) => {
    const cleanEmail = email.trim();
    if (!cleanEmail) throw new Error('Please enter your email address');
    await sendPasswordResetEmail(auth, cleanEmail);
  };

  const requestPasswordResetCode = async (email: string) => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) throw new Error('Please enter your email address.');
    const resp = await fetch('/api/auth/send-reset-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: cleanEmail }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) {
      const err: any = new Error(data.error || 'Could not send verification code.');
      err.code = data.code;
      throw err;
    }
    return data as { ok: boolean; emailSent?: boolean };
  };

  const verifyPasswordResetCode = async (email: string, code: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = code.trim();
    const resp = await fetch('/api/auth/verify-reset-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: cleanEmail, code: cleanCode }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.resetToken) {
      throw new Error(data.error || 'Invalid or expired verification code.');
    }
    return String(data.resetToken);
  };

  const completePasswordResetWithToken = async (
    email: string,
    resetToken: string,
    newPassword: string
  ) => {
    const cleanEmail = email.trim().toLowerCase();
    const resp = await fetch('/api/auth/complete-password-reset', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: cleanEmail, resetToken, newPassword }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) {
      throw new Error(data.error || 'Failed to update password.');
    }
  };

  const signOut = async () => {
    localStorage.removeItem(LOCAL_SESSION_KEY);
    await firebaseSignOut(auth).catch(() => {});
    setCurrentUser(null);
    setUserProfile(null);
    setIsAddingAccount(false);
  };

  const deleteAccount = async () => {
    if (!currentUser) return;
    const uid = currentUser.uid;
    const userEmail = (userProfile?.email || currentUser.email || '').trim().toLowerCase();

    // 1. Delete user's subcollections (devices & blocked)
    try {
      const devSnap = await getDocs(collection(db, 'users', uid, 'devices'));
      await Promise.all(devSnap.docs.map((d) => deleteDoc(d.ref).catch(() => {})));
    } catch {}
    try {
      const blkSnap = await getDocs(collection(db, 'users', uid, 'blocked'));
      await Promise.all(blkSnap.docs.map((d) => deleteDoc(d.ref).catch(() => {})));
    } catch {}

    // 2. Delete user's posts, stories, follows & notifications
    try {
      const postsSnap = await getDocs(query(collection(db, 'posts'), where('authorId', '==', uid)));
      await Promise.all(postsSnap.docs.map((d) => deleteDoc(d.ref).catch(() => {})));
    } catch {}
    try {
      const storiesSnap = await getDocs(query(collection(db, 'stories'), where('authorId', '==', uid)));
      await Promise.all(storiesSnap.docs.map((d) => deleteDoc(d.ref).catch(() => {})));
    } catch {}
    try {
      const f1Snap = await getDocs(query(collection(db, 'follows'), where('followerId', '==', uid)));
      const f2Snap = await getDocs(query(collection(db, 'follows'), where('followingId', '==', uid)));
      await Promise.all([
        ...f1Snap.docs.map((d) => deleteDoc(d.ref).catch(() => {})),
        ...f2Snap.docs.map((d) => deleteDoc(d.ref).catch(() => {})),
      ]);
    } catch {}
    try {
      const nSnap = await getDocs(query(collection(db, 'notifications'), where('recipientId', '==', uid)));
      await Promise.all(nSnap.docs.map((d) => deleteDoc(d.ref).catch(() => {})));
    } catch {}

    // 3. Release email lock and delete main user profile document
    if (userEmail) {
      await deleteDoc(doc(db, 'emailLocks', emailToRegistryId(userEmail))).catch(() => {});
    }
    await deleteDoc(doc(db, 'users', uid)).catch(() => {});

    // 4. Remove from local saved accounts & session caches
    removeSavedAccount(uid);
    localStorage.removeItem(LOCAL_SESSION_KEY);
    try {
      sessionStorage.removeItem(`ethio_2fa_ok_${uid}`);
      sessionStorage.removeItem(`ethio_applock_ok_${uid}`);
    } catch {}

    // 5. Permanently delete Firebase Auth user if signed in with Firebase Auth
    if (auth.currentUser && auth.currentUser.uid === uid) {
      try {
        await deleteUser(auth.currentUser);
      } catch (err: any) {
        if (
          err?.code === 'auth/requires-recent-login' &&
          auth.currentUser.providerData?.some((p) => p.providerId === 'google.com')
        ) {
          try {
            await reauthenticateWithPopup(auth.currentUser, new GoogleAuthProvider());
            await deleteUser(auth.currentUser);
          } catch {
            await firebaseSignOut(auth).catch(() => {});
          }
        } else {
          await firebaseSignOut(auth).catch(() => {});
        }
      }
    }

    setCurrentUser(null);
    setUserProfile(null);
    setIsAddingAccount(false);
  };

  const switchSavedAccount = async (account: SavedAccount) => {
    if (account.uid === currentUser?.uid) return;
    if (account.sessionType === 'local') {
      await firebaseSignOut(auth).catch(() => {});
      const localUser = {
        uid: account.uid,
        email: account.email,
        displayName: account.displayName,
        photoURL: account.photoURL || ''
      } as unknown as FirebaseUser;
      localStorage.setItem(LOCAL_SESSION_KEY, JSON.stringify(localUser));
      setCurrentUser(localUser);
    } else {
      // Prompt sign-in for Firebase credentialed account
      await firebaseSignOut(auth).catch(() => {});
      localStorage.removeItem(LOCAL_SESSION_KEY);
      setCurrentUser(null);
      setUserProfile(null);
    }
  };

  const removeSavedAccount = (uid: string) => {
    const next = readSavedAccounts().filter((a) => a.uid !== uid);
    try {
      localStorage.setItem(SAVED_ACCOUNTS_KEY, JSON.stringify(next));
    } catch {
      // ignore
    }
    setSavedAccounts(next);
  };

  // Edit Profile & Preferences functionality
  const updateUserProfileData = async (updates: {
    displayName?: string;
    photoURL?: string;
    coverURL?: string;
    bio?: string;
    email?: string;
    newPassword?: string;
    closeFriendsExcludedIds?: string[];
    selectedFriendIds?: string[];
    lastSeenVisibility?: 'everyone' | 'followers' | 'nobody';
    readReceiptsEnabled?: boolean;
    twoStepEnabled?: boolean;
    twoStepPin?: string;
    appLockEnabled?: boolean;
    appLockPin?: string;
    fontStyle?: string;
    fingerprintLockEnabled?: boolean;
    fingerprintCredentialId?: string;
    chatWallpaper?: string;
    chatFontSize?: 'small' | 'medium' | 'large';
    messageReactionsEnabled?: boolean;
    autoDownloadMedia?: boolean;
    lastBackupAt?: string;
  }) => {
    if (!currentUser || !userProfile) throw new Error('Not logged in');

    const firestoreUpdates: Partial<UserProfile> = {
      updatedAt: new Date().toISOString()
    };

    if (updates.displayName && updates.displayName.trim() !== '') {
      firestoreUpdates.displayName = updates.displayName.trim();
      try {
        await updateProfile(currentUser, { displayName: updates.displayName.trim() });
      } catch {}
    }

    if (updates.photoURL) {
      firestoreUpdates.photoURL = updates.photoURL;
      try {
        await updateProfile(currentUser, { photoURL: updates.photoURL });
      } catch {}
    }

    if (updates.coverURL !== undefined) {
      firestoreUpdates.coverURL = updates.coverURL;
    }

    if (updates.bio !== undefined) {
      firestoreUpdates.bio = updates.bio.trim();
    }

    if (updates.closeFriendsExcludedIds !== undefined) {
      firestoreUpdates.closeFriendsExcludedIds = updates.closeFriendsExcludedIds;
    }

    if (updates.selectedFriendIds !== undefined) {
      firestoreUpdates.selectedFriendIds = updates.selectedFriendIds;
    }

    if (updates.lastSeenVisibility !== undefined) {
      firestoreUpdates.lastSeenVisibility = updates.lastSeenVisibility;
    }

    if (updates.readReceiptsEnabled !== undefined) {
      firestoreUpdates.readReceiptsEnabled = updates.readReceiptsEnabled;
    }

    if (updates.twoStepEnabled !== undefined) {
      firestoreUpdates.twoStepEnabled = updates.twoStepEnabled;
    }

    if (updates.twoStepPin !== undefined) {
      firestoreUpdates.twoStepPin = updates.twoStepPin;
    }

    if (updates.appLockEnabled !== undefined) {
      firestoreUpdates.appLockEnabled = updates.appLockEnabled;
    }

    if (updates.appLockPin !== undefined) {
      firestoreUpdates.appLockPin = updates.appLockPin;
    }

    if (updates.fontStyle !== undefined) {
      firestoreUpdates.fontStyle = updates.fontStyle;
    }

    if (updates.fingerprintLockEnabled !== undefined) {
      firestoreUpdates.fingerprintLockEnabled = updates.fingerprintLockEnabled;
    }

    if (updates.fingerprintCredentialId !== undefined) {
      firestoreUpdates.fingerprintCredentialId = updates.fingerprintCredentialId;
    }

    if (updates.chatWallpaper !== undefined) {
      firestoreUpdates.chatWallpaper = updates.chatWallpaper;
    }

    if (updates.chatFontSize !== undefined) {
      firestoreUpdates.chatFontSize = updates.chatFontSize;
    }

    if (updates.messageReactionsEnabled !== undefined) {
      firestoreUpdates.messageReactionsEnabled = updates.messageReactionsEnabled;
    }

    if (updates.autoDownloadMedia !== undefined) {
      firestoreUpdates.autoDownloadMedia = updates.autoDownloadMedia;
    }

    if (updates.lastBackupAt !== undefined) {
      firestoreUpdates.lastBackupAt = updates.lastBackupAt;
    }

    if (updates.email) {
      const normalizedNewEmail = updates.email.trim().toLowerCase();
      const oldNormalizedEmail = (userProfile.email || currentUser.email || '').trim().toLowerCase();
      if (normalizedNewEmail && normalizedNewEmail !== oldNormalizedEmail) {
        await ensureEmailAvailableForUid(normalizedNewEmail, currentUser.uid);
        try {
          await updateEmail(currentUser, normalizedNewEmail);
        } catch (err: any) {
          if (err?.code === 'auth/email-already-in-use') {
            throw new Error('EMAIL_ALREADY_IN_USE');
          }
        }
        await claimEmailLock(normalizedNewEmail, currentUser.uid);
        if (oldNormalizedEmail) {
          await deleteDoc(doc(db, 'emailLocks', emailToRegistryId(oldNormalizedEmail))).catch(() => {});
        }
        firestoreUpdates.email = normalizedNewEmail;
      }
    }

    if (updates.newPassword && updates.newPassword.length >= 6) {
      try {
        await updatePassword(currentUser, updates.newPassword);
      } catch {}
    }

    await updateDoc(doc(db, 'users', currentUser.uid), firestoreUpdates).catch(async () => {
      await setDoc(doc(db, 'users', currentUser.uid), { ...userProfile, ...firestoreUpdates });
    });
    setUserProfile(prev => prev ? { ...prev, ...firestoreUpdates } : null);
  };

  // Toggle Online / Offline Privacy Visibility
  const toggleHideOnlineStatus = async () => {
    if (!currentUser || !userProfile) return;
    const nextHidden = !Boolean(userProfile.hideOnlineStatus);
    setUserProfile((prev) => (prev ? { ...prev, hideOnlineStatus: nextHidden } : null));
    await updateDoc(doc(db, 'users', currentUser.uid), {
      hideOnlineStatus: nextHidden,
      updatedAt: new Date().toISOString(),
    }).catch(() => {});
  };

  // Follow user
  const followUser = async (targetUserId: string) => {
    if (!currentUser || !userProfile || targetUserId === currentUser.uid) return;
    const followId = `${currentUser.uid}_${targetUserId}`;
    const followDocRef = doc(db, 'follows', followId);

    const followData: FollowRecord = {
      followId,
      followerId: currentUser.uid,
      followingId: targetUserId,
      createdAt: new Date().toISOString()
    };

    await setDoc(followDocRef, followData).catch(() => {});

    await updateDoc(doc(db, 'users', targetUserId), {
      followersCount: increment(1)
    }).catch(() => {});

    await updateDoc(doc(db, 'users', currentUser.uid), {
      followingCount: increment(1)
    }).catch(() => {});

    const isFollowBack = followerIds.has(targetUserId);
    await createAppNotification({
      recipientId: targetUserId,
      actor: userProfile,
      type: isFollowBack ? 'follow_back' : 'follow',
      text: isFollowBack ? 'followed you back' : 'started following you',
    });
  };

  // Unfollow user
  const unfollowUser = async (targetUserId: string) => {
    if (!currentUser || targetUserId === currentUser.uid) return;
    const followId = `${currentUser.uid}_${targetUserId}`;
    const followDocRef = doc(db, 'follows', followId);

    await deleteDoc(followDocRef).catch(() => {});

    await updateDoc(doc(db, 'users', targetUserId), {
      followersCount: increment(-1)
    }).catch(() => {});

    await updateDoc(doc(db, 'users', currentUser.uid), {
      followingCount: increment(-1)
    }).catch(() => {});
  };

  // Block / Unblock
  const blockUser = async (target: { userId: string; username: string; displayName: string; photoURL?: string }) => {
    if (!currentUser || target.userId === currentUser.uid) return;
    const record: BlockedUserRecord = {
      blockedUserId: target.userId,
      username: target.username,
      displayName: target.displayName,
      ...(target.photoURL ? { photoURL: target.photoURL } : {}),
      createdAt: new Date().toISOString(),
    };
    await setDoc(doc(db, 'users', currentUser.uid, 'blocked', target.userId), record);
  };

  const unblockUser = async (targetUserId: string) => {
    if (!currentUser) return;
    await deleteDoc(doc(db, 'users', currentUser.uid, 'blocked', targetUserId));
  };

  // Remove device session
  const removeDevice = async (deviceId: string) => {
    if (!currentUser) return;
    await deleteDoc(doc(db, 'users', currentUser.uid, 'devices', deviceId));
    if (deviceId === currentDeviceId) {
      await signOut();
    }
  };

  // Notifications Read
  const markNotificationRead = async (notificationId: string) => {
    await updateDoc(doc(db, 'notifications', notificationId), { read: true }).catch(() => {});
  };

  const markAllNotificationsRead = async () => {
    const unread = notifications.filter((n) => !n.read);
    await Promise.all(
      unread.map((n) => updateDoc(doc(db, 'notifications', n.notificationId), { read: true }).catch(() => {}))
    );
  };

  const unreadNotificationsCount = notifications.filter((n) => !n.read).length;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        loading,
        signIn,
        signUp,
        signInWithGoogle,
        resetPassword,
        requestPasswordResetCode,
        verifyPasswordResetCode,
        completePasswordResetWithToken,
        signOut,
        deleteAccount,
        updateUserProfileData,
        toggleHideOnlineStatus,
        followUser,
        unfollowUser,
        followingIds,
        followerIds,
        allUsers,
        savedAccounts,
        isAddingAccount,
        openAddAccount: () => setIsAddingAccount(true),
        closeAddAccount: () => setIsAddingAccount(false),
        switchSavedAccount,
        removeSavedAccount,
        blockedUsers,
        blockedIds,
        blockUser,
        unblockUser,
        devices,
        currentDeviceId,
        removeDevice,
        notifications,
        unreadNotificationsCount,
        markNotificationRead,
        markAllNotificationsRead
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
