import React, { useState, useRef, useEffect } from 'react';
import { useLanguage } from '../../context/LanguageContext';
import { useAuth } from '../../context/AuthContext';
import { compressImage } from '../../lib/mediaCompression';
import {
  X,
  Send,
  Sparkles,
  Bot,
  Trash2,
  Loader2,
  User,
  Image as ImageIcon
} from 'lucide-react';

interface RubGPTMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  imageUrl?: string;
  timestamp: string;
}

interface RubGPTModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RubGPTModal: React.FC<RubGPTModalProps> = ({ isOpen, onClose }) => {
  const { language, t } = useLanguage();
  const { userProfile } = useAuth();
  const [messages, setMessages] = useState<RubGPTMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text:
        language === 'om'
          ? 'Akkam! Ani RubGPT dha — gargaaraa AI Ethio Chat. Gaaffii barbaaddan gaafachuu ykn suuraa ergitanii waan isa keessa jiru na gaafachuu dandeessu!'
          : language === 'am'
          ? 'ሰላም! እኔ RubGPT ነኝ — የኢትዮ ቻት AI ረዳትዎ። ማንኛውንም ጥያቄ መጠየቅ ወይም ፎቶ ልከው ስለ ፎቶው መጠየቅ ይችላሉ!'
          : 'Hello! I am RubGPT, your Ethio Chat AI assistant. Ask any question or attach an image to ask about what is inside it!',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [selectedImageUrl, setSelectedImageUrl] = useState<string | null>(null);
  const [attachingImage, setAttachingImage] = useState(false);
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, sending]);

  if (!isOpen) return null;

  const handleImagePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAttachingImage(true);
    try {
      const compressed = await compressImage(file, 1024, 1024, 0.8);
      setSelectedImageUrl(compressed.dataUrl);
    } catch (err) {
      console.error('Failed to process image for RubGPT:', err);
    } finally {
      setAttachingImage(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const sendMessage = async (textOverride?: string) => {
    const promptText = (textOverride ?? input).trim();
    const imageToSend = textOverride ? null : selectedImageUrl;
    if ((!promptText && !imageToSend) || sending) return;

    const displayPrompt =
      promptText ||
      (language === 'om'
        ? 'Suuraa kana naaf ibsi.'
        : language === 'am'
        ? 'ይህን ምስል ግለጽልኝ።'
        : 'What is in this image?');

    const userMsg: RubGPTMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      text: displayPrompt,
      ...(imageToSend ? { imageUrl: imageToSend } : {}),
      timestamp: new Date().toISOString(),
    };

    const historyToSend = messages
      .filter((m) => m.id !== 'welcome')
      .map((m) => ({
        role: m.role,
        text: m.text,
        ...(m.imageUrl ? { imageUrl: m.imageUrl } : {}),
      }));

    setMessages((prev) => [...prev, userMsg]);
    if (!textOverride) {
      setInput('');
      setSelectedImageUrl(null);
    }
    setSending(true);

    try {
      const res = await fetch('/api/rubgpt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: displayPrompt,
          ...(imageToSend ? { imageUrl: imageToSend } : {}),
          history: historyToSend,
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data?.error || 'Could not get response from RubGPT');
      }

      const aiMsg: RubGPTMessage = {
        id: `m_${Date.now()}`,
        role: 'model',
        text: data.reply || 'No response generated.',
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev, aiMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          id: `err_${Date.now()}`,
          role: 'model',
          text: `⚠️ ${err?.message || 'Unable to connect to RubGPT right now.'}`,
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setSending(false);
    }
  };

  const quickPrompts =
    language === 'om'
      ? ['Seenaa Itoophiyaa gabaabinaan naaf himi', 'Xalayaa hojii bareedaa naaf barreessi', 'Afaan Oromo gara Ingliffaatti hiiki']
      : language === 'am'
      ? ['ስለ ኢትዮጵያ ታሪክ በአጭሩ ንገረኝ', 'ጥሩ የስራ መልዕክት ጻፍልኝ', 'አማርኛ ወደ እንግሊዝኛ ተርጉም']
      : ['Write a friendly greeting post', 'Translate a message to Afaan Oromo', 'Give me 3 creative study tips'];

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#16132b] w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200/80 dark:border-purple-950/60 flex flex-col h-[88vh] sm:h-[680px] overflow-hidden">
        {/* Top Bar */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-purple-950/40 flex items-center justify-between bg-gradient-to-r from-[#7560DF]/15 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-[#7560DF] to-[#A494FA] text-white flex items-center justify-center shadow-md shadow-[#7560DF]/30">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                <span>RubGPT</span>
                <Sparkles className="w-4 h-4 text-[#7560DF]" />
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {t('rubGptDesc')}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => {
                setMessages((prev) => prev.slice(0, 1));
                setSelectedImageUrl(null);
              }}
              className="p-2 rounded-full text-slate-400 hover:text-rose-500 hover:bg-slate-100 dark:hover:bg-purple-950/40"
              title="Clear chat"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-purple-950/40"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/70 dark:bg-[#0f0d1a]">
          {messages.map((m) => {
            const isUser = m.role === 'user';
            return (
              <div key={m.id} className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}>
                {!isUser && (
                  <div className="w-8 h-8 rounded-full bg-[#7560DF] text-white flex items-center justify-center shrink-0 mt-1">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap break-words shadow-sm space-y-2 ${
                    isUser
                      ? 'bg-[#7560DF] text-white rounded-br-sm'
                      : 'bg-white dark:bg-[#1f1b38] text-slate-800 dark:text-slate-100 border border-slate-200/80 dark:border-purple-950/40 rounded-bl-sm'
                  }`}
                >
                  {m.imageUrl && (
                    <img
                      src={m.imageUrl}
                      alt="Uploaded to RubGPT"
                      className="max-h-56 w-auto rounded-xl object-cover border border-white/20"
                    />
                  )}
                  {m.text && <div>{m.text}</div>}
                </div>
                {isUser && userProfile && (
                  <div className="w-8 h-8 rounded-full overflow-hidden shrink-0 mt-1 ring-1 ring-[#7560DF]/40">
                    {userProfile.photoURL ? (
                      <img src={userProfile.photoURL} alt={userProfile.displayName} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-slate-200 flex items-center justify-center">
                        <User className="w-4 h-4 text-slate-500" />
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}

          {sending && (
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-[#7560DF] text-white flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="px-4 py-2.5 rounded-2xl bg-white dark:bg-[#1f1b38] border border-slate-200/80 dark:border-purple-950/40 text-xs text-slate-500 flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-[#7560DF]" />
                <span>
                  {language === 'om'
                    ? 'RubGPT yaadaa jira...'
                    : language === 'am'
                    ? 'RubGPT እያሰበ ነው...'
                    : 'RubGPT is thinking...'}
                </span>
              </div>
            </div>
          )}

          {messages.length <= 1 && (
            <div className="pt-2 flex flex-wrap gap-2">
              {quickPrompts.map((q) => (
                <button
                  key={q}
                  onClick={() => sendMessage(q)}
                  className="px-3 py-1.5 rounded-full bg-white dark:bg-[#1f1b38] border border-[#7560DF]/30 text-xs font-medium text-[#7560DF] dark:text-[#B09EFC] hover:bg-[#7560DF]/10 transition-colors"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          <div ref={endRef} />
        </div>

        {/* Selected Image Preview Strip */}
        {selectedImageUrl && (
          <div className="px-4 py-2.5 border-t border-slate-100 dark:border-purple-950/40 bg-slate-50 dark:bg-[#120f24] flex items-center gap-3">
            <div className="relative w-14 h-14 rounded-xl overflow-hidden border border-[#7560DF]/40 shrink-0">
              <img src={selectedImageUrl} alt="Preview" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => setSelectedImageUrl(null)}
                className="absolute top-0.5 right-0.5 p-0.5 rounded-full bg-black/70 text-white hover:bg-rose-500"
                title="Remove image"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-300">
              {language === 'om'
                ? 'Suuraan qophaa’eera! Gaaffii barreessiitii ergi.'
                : language === 'am'
                ? 'ፎቶው ዝግጁ ነው! ጥያቄዎን ጽፈው ይላኩ።'
                : 'Image ready! Type a question about this photo or press Send.'}
            </p>
          </div>
        )}

        {/* Input */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage();
          }}
          className="p-3.5 border-t border-slate-100 dark:border-purple-950/40 bg-white dark:bg-[#16132b] flex items-center gap-2 safe-bottom"
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleImagePick}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={attachingImage || sending}
            className="p-2.5 rounded-full bg-slate-100 dark:bg-[#201c38] text-[#7560DF] hover:bg-[#7560DF]/15 transition-colors disabled:opacity-40 shrink-0"
            title={language === 'om' ? 'Suuraa ergi' : language === 'am' ? 'ፎቶ ላክ' : 'Attach image'}
          >
            {attachingImage ? <Loader2 className="w-4.5 h-4.5 animate-spin" /> : <ImageIcon className="w-4.5 h-4.5" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              selectedImageUrl
                ? language === 'om'
                  ? 'Waa’ee suuraa kanaa gaafadhu...'
                  : language === 'am'
                  ? 'ስለዚህ ፎቶ ይጠይቁ...'
                  : 'Ask about this image...'
                : language === 'om'
                ? 'RubGPT gaafadhu ykn suuraa ergi...'
                : language === 'am'
                ? 'RubGPTን ይጠይቁ ወይም ፎቶ ይላኩ...'
                : 'Ask RubGPT anything or attach a photo...'
            }
            className="flex-1 px-4 py-2.5 rounded-full bg-slate-100 dark:bg-[#201c38] text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
          />
          <button
            type="submit"
            disabled={(!input.trim() && !selectedImageUrl) || sending}
            className="p-2.5 rounded-full bg-[#7560DF] hover:bg-[#624ec7] text-white disabled:opacity-40 shadow-sm transition-all shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
