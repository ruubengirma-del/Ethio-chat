import React, { useEffect, useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { db } from '../../lib/firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { ViewStatEvent } from '../../types';
import {
  X,
  BarChart3,
  Eye,
  Calendar,
  TrendingUp,
  UserCheck,
  Image as ImageIcon,
  Radio
} from 'lucide-react';

interface DashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DashboardModal: React.FC<DashboardModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, userProfile } = useAuth();
  const { t } = useLanguage();
  const [events, setEvents] = useState<ViewStatEvent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isOpen || !currentUser) return;

    const q = query(
      collection(db, 'viewStats'),
      where('targetUserId', '==', currentUser.uid)
    );

    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const list: ViewStatEvent[] = [];
        snapshot.forEach((d) => list.push(d.data() as ViewStatEvent));
        setEvents(list);
        setLoading(false);
      },
      () => setLoading(false)
    );

    return () => unsub();
  }, [isOpen, currentUser]);

  const stats = useMemo(() => {
    const now = Date.now();
    const monthAgo = now - 30 * 24 * 60 * 60 * 1000;
    const yearAgo = now - 365 * 24 * 60 * 60 * 1000;

    let monthlyViews = 0;
    let yearlyViews = 0;
    let profileViews = 0;
    let postViews = 0;
    let storyViews = 0;

    events.forEach((ev) => {
      const ts = new Date(ev.createdAt).getTime();
      if (ts >= monthAgo) monthlyViews++;
      if (ts >= yearAgo) yearlyViews++;
      if (ev.kind === 'profile') profileViews++;
      else if (ev.kind === 'post') postViews++;
      else if (ev.kind === 'story') storyViews++;
    });

    const totalViews = Math.max(events.length, userProfile?.profileViewsCount || 0);
    return {
      monthlyViews,
      yearlyViews,
      totalViews,
      profileViews: Math.max(profileViews, userProfile?.profileViewsCount || 0),
      postViews,
      storyViews,
    };
  }, [events, userProfile]);

  if (!isOpen || !userProfile) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#16132b] w-full max-w-md rounded-3xl shadow-2xl border border-slate-200/80 dark:border-purple-950/60 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-purple-950/40 flex items-center justify-between bg-gradient-to-r from-[#7560DF]/15 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#7560DF] text-white flex items-center justify-center shadow-md shadow-[#7560DF]/25">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                {t('dashboard')}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                @{userProfile.username} • Account Views & Reach
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-purple-950/40"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 overflow-y-auto">
          {/* Primary Monthly & Yearly Cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 rounded-2xl bg-gradient-to-br from-[#7560DF] to-[#5642bd] text-white shadow-lg shadow-[#7560DF]/25">
              <div className="flex items-center justify-between text-white/80 text-xs font-semibold mb-1">
                <span>Monthly Views</span>
                <Calendar className="w-4 h-4" />
              </div>
              <p className="text-3xl font-black tracking-tight">
                {loading ? '—' : stats.monthlyViews}
              </p>
              <p className="text-[11px] text-white/75 mt-1">Last 30 days</p>
            </div>

            <div className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg shadow-emerald-500/20">
              <div className="flex items-center justify-between text-white/80 text-xs font-semibold mb-1">
                <span>Yearly Views</span>
                <TrendingUp className="w-4 h-4" />
              </div>
              <p className="text-3xl font-black tracking-tight">
                {loading ? '—' : stats.yearlyViews}
              </p>
              <p className="text-[11px] text-white/75 mt-1">Last 365 days</p>
            </div>
          </div>

          {/* All-Time Total Views */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200/80 dark:border-purple-950/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#7560DF]/15 text-[#7560DF] flex items-center justify-center">
                <Eye className="w-5 h-5" />
              </div>
              <div>
                <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
                  All-Time Account Views
                </p>
                <p className="text-xl font-extrabold text-slate-900 dark:text-white">
                  {stats.totalViews} Views
                </p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-[#7560DF]/15 text-[#7560DF] dark:text-[#B09EFC] text-xs font-bold">
              Live
            </span>
          </div>

          {/* Breakdown by Source */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Breakdown by Content
            </h4>

            <div className="grid grid-cols-3 gap-2.5">
              <div className="p-3 rounded-2xl bg-white dark:bg-[#1a1633] border border-slate-200/80 dark:border-purple-950/50 text-center">
                <UserCheck className="w-4 h-4 text-[#7560DF] mx-auto mb-1" />
                <p className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {stats.profileViews}
                </p>
                <p className="text-[11px] text-slate-400">Profile</p>
              </div>

              <div className="p-3 rounded-2xl bg-white dark:bg-[#1a1633] border border-slate-200/80 dark:border-purple-950/50 text-center">
                <ImageIcon className="w-4 h-4 text-blue-500 mx-auto mb-1" />
                <p className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {stats.postViews}
                </p>
                <p className="text-[11px] text-slate-400">Posts</p>
              </div>

              <div className="p-3 rounded-2xl bg-white dark:bg-[#1a1633] border border-slate-200/80 dark:border-purple-950/50 text-center">
                <Radio className="w-4 h-4 text-rose-500 mx-auto mb-1" />
                <p className="text-lg font-extrabold text-slate-900 dark:text-white">
                  {stats.storyViews}
                </p>
                <p className="text-[11px] text-slate-400">Stories</p>
              </div>
            </div>
          </div>

          {/* Audience Summary */}
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200/80 dark:border-purple-950/50 flex items-center justify-around text-center">
            <div>
              <p className="text-lg font-extrabold text-slate-900 dark:text-white">
                {userProfile.followersCount || 0}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{t('followers')}</p>
            </div>
            <div className="w-px h-8 bg-slate-200 dark:bg-purple-900/50" />
            <div>
              <p className="text-lg font-extrabold text-slate-900 dark:text-white">
                {userProfile.followingCount || 0}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">{t('following')}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
