import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { compressImage } from '../../lib/mediaCompression';
import { 
  X, 
  Camera, 
  User, 
  Mail, 
  Lock, 
  FileText, 
  Check, 
  Loader2, 
  AlertCircle,
  Image as ImageIcon
} from 'lucide-react';

interface EditProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EditProfileModal: React.FC<EditProfileModalProps> = ({ isOpen, onClose }) => {
  const { userProfile, updateUserProfileData } = useAuth();
  const { t } = useLanguage();

  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [bio, setBio] = useState(userProfile?.bio || '');
  const [email, setEmail] = useState(userProfile?.email || '');
  const [newPassword, setNewPassword] = useState('');
  const [photoURL, setPhotoURL] = useState(userProfile?.photoURL || '');
  const [coverURL, setCoverURL] = useState(userProfile?.coverURL || '');
  const [isSaving, setIsSaving] = useState(false);
  const [isCompressingPhoto, setIsCompressingPhoto] = useState(false);
  const [isCompressingCover, setIsCompressingCover] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen && userProfile) {
      setDisplayName(userProfile.displayName || '');
      setBio(userProfile.bio || '');
      setEmail(userProfile.email || '');
      setPhotoURL(userProfile.photoURL || '');
      setCoverURL(userProfile.coverURL || '');
      setNewPassword('');
      setErrorMsg(null);
      setSuccessMsg(null);
    }
  }, [isOpen, userProfile]);

  if (!isOpen || !userProfile) return null;

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressingPhoto(true);
    setErrorMsg(null);
    try {
      const res = await compressImage(file, 450, 450, 0.8);
      setPhotoURL(res.dataUrl);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to compress profile photo');
    } finally {
      setIsCompressingPhoto(false);
    }
  };

  const handleCoverSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsCompressingCover(true);
    setErrorMsg(null);
    try {
      const res = await compressImage(file, 1000, 480, 0.78);
      setCoverURL(res.dataUrl);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to compress cover photo');
    } finally {
      setIsCompressingCover(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setErrorMsg(null);
    setSuccessMsg(null);

    try {
      await updateUserProfileData({
        displayName,
        bio,
        email,
        photoURL,
        coverURL,
        newPassword: newPassword ? newPassword : undefined
      });
      setSuccessMsg('Profile updated successfully!');
      setTimeout(() => {
        onClose();
      }, 900);
    } catch (err: any) {
      const msg = err?.message || '';
      setErrorMsg(msg.includes('EMAIL_ALREADY_IN_USE') ? t('emailAlreadyInUse') : (msg || 'Failed to update profile'));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#16132b] w-full max-w-md rounded-3xl shadow-2xl border border-slate-100 dark:border-purple-950/60 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-slate-100 dark:border-purple-950/40 flex items-center justify-between">
          <h2 className="font-bold text-base text-slate-900 dark:text-white">
            Edit Profile
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-purple-900/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="p-5 overflow-y-auto space-y-4 flex-1">
          {/* Cover Photo Picker */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <ImageIcon className="w-3.5 h-3.5 text-[#7560DF]" />
              <span>Cover Photo</span>
            </label>
            <div
              onClick={() => coverInputRef.current?.click()}
              className="relative h-24 rounded-2xl overflow-hidden bg-gradient-to-r from-[#503cb3] via-[#7560DF] to-[#9986fa] cursor-pointer group border border-slate-200 dark:border-purple-900/50"
            >
              {coverURL && (
                <img src={coverURL} alt="Cover preview" className="w-full h-full object-cover" />
              )}
              <div className="absolute inset-0 bg-black/35 flex items-center justify-center gap-1.5 text-white text-xs font-bold opacity-85 group-hover:opacity-100 transition-opacity">
                <Camera className="w-4 h-4" />
                <span>{isCompressingCover ? 'Optimizing cover...' : 'Change Cover Photo'}</span>
              </div>
            </div>
            <input
              type="file"
              ref={coverInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleCoverSelect}
            />
          </div>

          {/* Change Avatar */}
          <div className="flex flex-col items-center gap-2">
            <div className="relative group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
              <img
                src={photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${userProfile.username}`}
                alt={displayName}
                className="w-20 h-20 rounded-full object-cover ring-4 ring-[#7560DF]/30 shadow-md"
              />
              <div className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <Camera className="w-6 h-6 text-white" />
              </div>
              <button
                type="button"
                className="absolute bottom-0 right-0 p-1.5 rounded-full bg-[#7560DF] text-white shadow-md"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handlePhotoSelect}
            />
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {isCompressingPhoto ? 'Optimizing photo...' : 'Tap to change profile picture'}
            </span>
          </div>

          {/* Display Name */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-[#7560DF]" />
              <span>Display Name</span>
            </label>
            <input
              type="text"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-950/60 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-[#7560DF]"
            />
          </div>

          {/* Bio */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5 text-[#7560DF]" />
              <span>Bio / Status</span>
            </label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              rows={2}
              maxLength={250}
              placeholder="Tell other Ethiopian users about yourself..."
              className="w-full px-3.5 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-950/60 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-[#7560DF] resize-none"
            />
          </div>

          {/* Change Email */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#7560DF]" />
              <span>Email Address</span>
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-950/60 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-[#7560DF]"
            />
          </div>

          {/* Change Password */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-[#7560DF]" />
              <span>New Password (optional)</span>
            </label>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Leave blank to keep current password"
              minLength={6}
              className="w-full px-3.5 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-950/60 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-[#7560DF] placeholder:text-slate-400"
            />
          </div>

          {successMsg && (
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-500" />
              <span>{successMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-500" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSaving || isCompressingPhoto || isCompressingCover}
              className="w-full py-3 rounded-2xl bg-[#7560DF] hover:bg-[#624ec7] text-white font-bold text-sm shadow-md shadow-[#7560DF]/25 transition-all flex items-center justify-center gap-2"
            >
              {isSaving ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Saving Updates...</span>
                </>
              ) : (
                <span>Save Changes</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
