import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { AppNotification } from '../../types';
import {
  X,
  Bell,
  Heart,
  MessageCircle,
  AtSign,
  UserPlus,
  Users,
  CheckCheck,
  Share2
} from 'lucide-react';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToProfile: (userId: string) => void;
  onNavigateToChat: (chatId: string) => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  onNavigateToProfile,
  onNavigateToChat,
}) => {
  const { notifications, unreadNotificationsCount, markNotificationRead, markAllNotificationsRead } = useAuth();
  const { t } = useLanguage();

  if (!isOpen) return null;

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'like':
        return <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />;
      case 'comment':
        return <MessageCircle className="w-4 h-4 text-[#7560DF]" />;
      case 'mention':
        return <AtSign className="w-4 h-4 text-amber-500" />;
      case 'follow':
      case 'follow_back':
        return <UserPlus className="w-4 h-4 text-emerald-500" />;
      case 'group':
        return <Users className="w-4 h-4 text-blue-500" />;
      case 'share':
        return <Share2 className="w-4 h-4 text-[#7560DF]" />;
      default:
        return <Bell className="w-4 h-4 text-[#7560DF]" />;
    }
  };

  const getLabel = (n: AppNotification) => {
    switch (n.type) {
      case 'like':
        return 'liked your post';
      case 'comment':
        return 'commented on your post';
      case 'mention':
        return 'mentioned you';
      case 'follow':
        return 'added / followed you';
      case 'follow_back':
        return 'followed you back';
      case 'group':
        return 'group activity';
      case 'share':
        return 'shared a post with you';
      default:
        return 'sent an update';
    }
  };

  const formatTime = (iso: string) => {
    try {
      const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
      if (diff < 60) return 'Just now';
      if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
      if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
      return `${Math.floor(diff / 86400)}d ago`;
    } catch {
      return '';
    }
  };

  const handleTap = async (n: AppNotification) => {
    if (!n.read) {
      await markNotificationRead(n.notificationId);
    }
    if ((n.type === 'group' || n.type === 'share') && n.chatId) {
      onClose();
      onNavigateToChat(n.chatId);
      return;
    }
    onClose();
    onNavigateToProfile(n.actorId);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#16132b] w-full max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200/80 dark:border-purple-950/60 flex flex-col h-[82vh] sm:h-[620px] overflow-hidden">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-purple-950/40 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[#7560DF]/15 text-[#7560DF] flex items-center justify-center">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                {t('notifications')}
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {unreadNotificationsCount} unread
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {unreadNotificationsCount > 0 && (
              <button
                onClick={() => markAllNotificationsRead()}
                className="px-2.5 py-1.5 rounded-xl bg-[#7560DF]/10 text-[#7560DF] dark:text-[#B09EFC] text-xs font-bold flex items-center gap-1 hover:bg-[#7560DF]/20"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span>{t('markAllRead')}</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* List */}
        <div className="flex-1 p-4 overflow-y-auto space-y-2.5">
          {notifications.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-slate-400 space-y-2 p-6">
              <Bell className="w-10 h-10 opacity-30 text-[#7560DF]" />
              <p className="text-sm font-bold text-slate-700 dark:text-slate-300">
                {t('noNotifications')}
              </p>
              <p className="text-xs max-w-xs">
                Likes, comments, @mentions, friend requests, follow backs, and group updates will appear here in real time.
              </p>
            </div>
          ) : (
            notifications.map((n) => (
              <button
                key={n.notificationId}
                onClick={() => handleTap(n)}
                className={`w-full p-3.5 rounded-2xl border text-left flex items-start gap-3 transition-all ${
                  n.read
                    ? 'border-slate-200/70 dark:border-purple-950/40 bg-white dark:bg-[#1a1633]'
                    : 'border-[#7560DF]/40 bg-[#7560DF]/10 dark:bg-[#7560DF]/15'
                }`}
              >
                <div className="relative shrink-0">
                  <img
                    src={n.actorPhotoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${n.actorUsername}`}
                    alt={n.actorDisplayName}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-white dark:bg-[#16132b] flex items-center justify-center shadow">
                    {getIcon(n.type)}
                  </span>
                </div>

                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-100 leading-snug">
                    <span className="font-bold">{n.actorDisplayName}</span>{' '}
                    <span className="text-slate-500 dark:text-slate-400">(@{n.actorUsername})</span>{' '}
                    <span>{getLabel(n)}</span>
                  </p>
                  {n.text && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2 italic">
                      "{n.text}"
                    </p>
                  )}
                  <p className="text-[10px] text-slate-400 mt-1">{formatTime(n.createdAt)}</p>
                </div>

                {!n.read && <span className="w-2.5 h-2.5 rounded-full bg-[#7560DF] shrink-0 mt-1.5" />}
              </button>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
