import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useLanguage } from '../../context/LanguageContext';
import { 
  Lock, 
  Mail, 
  User, 
  Loader2, 
  AlertCircle, 
  ArrowRight,
  X,
  KeyRound,
  CheckCircle2,
  ShieldCheck
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose?: () => void;
}

type ForgotStep = 'email' | 'code' | 'new_password';

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const {
    signIn,
    signUp,
    signInWithGoogle,
    resetPassword,
    requestPasswordResetCode,
    verifyPasswordResetCode,
    completePasswordResetWithToken,
  } = useAuth();
  const { t } = useLanguage();
  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot'>('signin');
  const [forgotStep, setForgotStep] = useState<ForgotStep>('email');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Forgot password OTP states
  const [verificationCode, setVerificationCode] = useState('');
  const [resetToken, setResetToken] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [showFirebaseResetBackup, setShowFirebaseResetBackup] = useState(false);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const resetForgotFlow = () => {
    setForgotStep('email');
    setVerificationCode('');
    setResetToken('');
    setNewPassword('');
    setConfirmNewPassword('');
    setShowFirebaseResetBackup(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (mode === 'forgot') {
        if (forgotStep === 'email') {
          await requestPasswordResetCode(email);
          setForgotStep('code');
          setShowFirebaseResetBackup(false);
          setSuccessMsg('A 6-digit verification code has been sent to your email.');
        } else if (forgotStep === 'code') {
          if (!verificationCode.trim()) {
            throw new Error('Please enter the verification code sent to your email.');
          }
          const token = await verifyPasswordResetCode(email, verificationCode);
          setResetToken(token);
          setForgotStep('new_password');
          setSuccessMsg('Code verified! Enter your new password below.');
        } else {
          if (newPassword.length < 6) {
            throw new Error('New password must be at least 6 characters.');
          }
          if (newPassword !== confirmNewPassword) {
            throw new Error('Passwords do not match.');
          }
          await completePasswordResetWithToken(email, resetToken, newPassword);
          setMode('signin');
          resetForgotFlow();
          setPassword('');
          setSuccessMsg('Password updated! You can now log in with your new password.');
        }
      } else if (mode === 'signup') {
        if (!username.trim()) throw new Error('Please choose a username');
        if (password.length < 6) throw new Error('Password must be at least 6 characters');
        await signUp(username, email, password, displayName || undefined);
      } else {
        await signIn(email, password);
      }
    } catch (err: any) {
      let msg = err.message || 'Authentication failed. Please check your details.';
      if (err?.code === 'EMAIL_SERVICE_NOT_CONFIGURED') {
        setShowFirebaseResetBackup(true);
      }
      if (msg.includes('auth/invalid-credential') || msg.includes('auth/user-not-found') || msg.includes('auth/wrong-password')) {
        msg = 'Invalid email or password. Please check your credentials or continue with Google.';
      } else if (msg.includes('auth/email-already-in-use') || msg.includes('EMAIL_ALREADY_IN_USE')) {
        msg = t('emailAlreadyInUse');
      }
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleFirebaseResetBackup = async () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      await resetPassword(email);
      setSuccessMsg(t('resetEmailSent'));
    } catch (err: any) {
      setErrorMsg(err?.message || 'Could not send reset email.');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      await signInWithGoogle();
    } catch (err: any) {
      let msg = err.message || 'Google sign-in was cancelled';
      if (msg.includes('EMAIL_ALREADY_IN_USE') || msg.includes('auth/email-already-in-use')) {
        msg = t('emailAlreadyInUse');
      }
      setErrorMsg(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-md animate-in fade-in duration-300">
      <div className="relative bg-white dark:bg-[#16132b] w-full max-w-md rounded-3xl shadow-2xl border border-slate-100 dark:border-purple-950/60 overflow-hidden flex flex-col max-h-[95vh] overflow-y-auto">
        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-purple-950/40 z-10"
            title="Cancel Add Account"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Brand Banner */}
        <div className="pt-7 pb-4 px-6 text-center bg-gradient-to-b from-[#7560DF]/15 via-transparent to-transparent flex flex-col items-center">
          <div className="w-16 h-16 rounded-3xl p-1 bg-gradient-to-tr from-[#7560DF] to-[#A494FA] shadow-xl shadow-[#7560DF]/30 mb-2.5 flex items-center justify-center bg-white overflow-hidden">
            <img
              src="/assets/aistudio/20261111_152710_57efcc53.png"
              alt="Ethio Chat Logo"
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
          </div>

          <h1 className="text-xl font-black tracking-tight text-slate-900 dark:text-white">
            ETHIO CHAT
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 max-w-xs font-medium">
            Modern Ethiopian Social Media & Real-Time Messenger
          </p>

          {mode !== 'forgot' && (
            <button
              type="button"
              disabled={loading}
              onClick={handleGoogleSignIn}
              className="w-full mt-4 py-2.5 px-4 rounded-2xl bg-white dark:bg-[#201c38] hover:bg-slate-50 dark:hover:bg-[#272244] text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-purple-950/60 font-bold text-xs sm:text-sm flex items-center justify-center gap-2.5 shadow-sm transition-all"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Continue with Google</span>
            </button>
          )}

          <div className="flex items-center gap-2 w-full my-3">
            <div className="h-px bg-slate-200 dark:bg-purple-950/50 flex-1" />
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
              {mode === 'forgot'
                ? forgotStep === 'email'
                  ? '1. Send Email Code'
                  : forgotStep === 'code'
                  ? '2. Verify Code'
                  : '3. New Password'
                : 'Or Use Email & Password'}
            </span>
            <div className="h-px bg-slate-200 dark:bg-purple-950/50 flex-1" />
          </div>

          {mode !== 'forgot' && (
            <div className="p-1 bg-slate-100 dark:bg-[#201c38] rounded-2xl flex items-center w-full border border-slate-200/60 dark:border-purple-950/40">
              <button
                type="button"
                onClick={() => { setMode('signin'); setErrorMsg(null); setSuccessMsg(null); }}
                className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
                  mode === 'signin'
                    ? 'bg-white dark:bg-[#7560DF] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
                }`}
              >
                Log In
              </button>
              <button
                type="button"
                onClick={() => { setMode('signup'); setErrorMsg(null); setSuccessMsg(null); }}
                className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
                  mode === 'signup'
                    ? 'bg-white dark:bg-[#7560DF] text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
                }`}
              >
                Sign Up
              </button>
            </div>
          )}
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="px-6 pb-5 space-y-3">
          {mode === 'signup' && (
            <>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Username (@handle)
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. abel_tadesse"
                    className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  Full Display Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="e.g. Abel Tadesse"
                    className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
                  />
                </div>
              </div>
            </>
          )}

          {/* Email field */}
          {(mode !== 'forgot' || forgotStep === 'email') && (
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
                />
              </div>
            </div>
          )}

          {/* Forgot Step 2: 6-Digit Verification Code Input */}
          {mode === 'forgot' && forgotStep === 'code' && (
            <div className="space-y-2">
              <div className="px-3 py-2 rounded-xl bg-slate-100 dark:bg-[#201c38] text-xs text-slate-600 dark:text-slate-300 flex items-center justify-between gap-2">
                <span className="truncate font-semibold">{email}</span>
                <button
                  type="button"
                  onClick={() => {
                    setForgotStep('email');
                    setErrorMsg(null);
                    setSuccessMsg(null);
                  }}
                  className="text-[#7560DF] dark:text-[#A798F8] font-bold hover:underline shrink-0"
                >
                  Change
                </button>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  {t('verificationCodeLabel')}
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    inputMode="numeric"
                    required
                    maxLength={8}
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="123456"
                    className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-base font-mono tracking-[0.35em] text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Forgot Step 3: New Password Form */}
          {mode === 'forgot' && forgotStep === 'new_password' && (
            <div className="space-y-2.5">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  {t('newPasswordLabel')}
                </label>
                <div className="relative">
                  <ShieldCheck className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-emerald-500" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Min 6 characters"
                    className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-[#7560DF]"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                  {t('confirmPasswordLabel')}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    placeholder="Confirm new password"
                    className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-[#7560DF]"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Regular Password */}
          {mode !== 'forgot' && (
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
                />
              </div>
            </div>
          )}

          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/40 text-rose-700 dark:text-rose-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/40 text-emerald-700 dark:text-emerald-300 text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-2xl bg-[#7560DF] hover:bg-[#624ec7] text-white font-bold text-sm shadow-md shadow-[#7560DF]/25 transition-all flex items-center justify-center gap-2 mt-1"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Processing...</span>
              </>
            ) : (
              <>
                <span>
                  {mode === 'forgot'
                    ? forgotStep === 'email'
                      ? t('sendCodeBtn')
                      : forgotStep === 'code'
                      ? t('verifyCodeBtn')
                      : t('updatePasswordBtn')
                    : mode === 'signup'
                    ? 'Create Account'
                    : 'Log In to Ethio Chat'}
                </span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          {mode === 'forgot' && showFirebaseResetBackup && (
            <button
              type="button"
              disabled={loading || !email.trim()}
              onClick={handleFirebaseResetBackup}
              className="w-full py-2 rounded-2xl border border-[#7560DF]/40 text-[#7560DF] dark:text-[#B09EFC] font-bold text-xs hover:bg-[#7560DF]/10 transition-colors"
            >
              {t('sendResetLink')} (Firebase)
            </button>
          )}

          {mode === 'signin' && (
            <div className="text-center pt-1">
              <button
                type="button"
                onClick={() => {
                  setMode('forgot');
                  resetForgotFlow();
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }}
                className="text-xs font-bold text-[#7560DF] dark:text-[#A798F8] hover:underline"
              >
                {t('forgotPassword')}
              </button>
            </div>
          )}

          {mode === 'forgot' && (
            <div className="text-center pt-1">
              <button
                type="button"
                onClick={() => {
                  setMode('signin');
                  resetForgotFlow();
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }}
                className="text-xs font-bold text-slate-500 dark:text-slate-400 hover:text-[#7560DF] hover:underline"
              >
                {t('backToLogin')}
              </button>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};
