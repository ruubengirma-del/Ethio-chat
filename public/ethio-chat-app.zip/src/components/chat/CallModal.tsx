import React, { useEffect, useRef, useState } from 'react';
import { CallSession } from '../../types';
import { db } from '../../lib/firebase';
import {
  doc,
  onSnapshot,
  updateDoc,
  collection,
  addDoc,
} from 'firebase/firestore';
import {
  Phone,
  PhoneOff,
  Video,
  VideoOff,
  Mic,
  MicOff,
  X
} from 'lucide-react';

interface CallModalProps {
  call: CallSession | null;
  currentUserId: string;
  onClose: () => void;
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

export const CallModal: React.FC<CallModalProps> = ({ call, currentUserId, onClose }) => {
  const [liveCall, setLiveCall] = useState<CallSession | null>(call);
  const [micMuted, setMicMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [elapsedSec, setElapsedSec] = useState(0);
  const [mediaError, setMediaError] = useState<string | null>(null);

  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null);
  const answerSetRef = useRef(false);

  const isCaller = call?.callerId === currentUserId;
  const isVideo = (liveCall?.callType || call?.callType) === 'video';

  const cleanupMedia = () => {
    try {
      localStreamRef.current?.getTracks().forEach((tr) => tr.stop());
    } catch {}
    localStreamRef.current = null;
    try {
      pcRef.current?.close();
    } catch {}
    pcRef.current = null;
    answerSetRef.current = false;
  };

  // Keep liveCall synced with Firestore
  useEffect(() => {
    if (!call) return;
    setLiveCall(call);
    const unsub = onSnapshot(doc(db, 'calls', call.callId), (snap) => {
      if (snap.exists()) {
        const updated = snap.data() as CallSession;
        setLiveCall(updated);
        if (updated.status === 'ended' || updated.status === 'declined') {
          cleanupMedia();
          setTimeout(() => onClose(), 800);
        }
      }
    });
    return () => unsub();
  }, [call?.callId]);

  // Call timer when active
  useEffect(() => {
    if (liveCall?.status !== 'active') {
      setElapsedSec(0);
      return;
    }
    const timer = setInterval(() => setElapsedSec((s) => s + 1), 1000);
    return () => clearInterval(timer);
  }, [liveCall?.status]);

  // Caller sets up RTCPeerConnection + offer
  useEffect(() => {
    if (!call || !isCaller) return;
    let unsubAnswerCand: (() => void) | null = null;
    let unsubDoc: (() => void) | null = null;

    const startCaller = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: call.callType === 'video',
        });
        localStreamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        const pc = new RTCPeerConnection(RTC_CONFIG);
        pcRef.current = pc;

        stream.getTracks().forEach((track) => pc.addTrack(track, stream));

        pc.ontrack = (event) => {
          const remoteStream = event.streams[0];
          if (remoteVideoRef.current) remoteVideoRef.current.srcObject = remoteStream;
          if (remoteAudioRef.current) remoteAudioRef.current.srcObject = remoteStream;
        };

        const callerCandidatesRef = collection(db, 'calls', call.callId, 'callerCandidates');
        pc.onicecandidate = (ev) => {
          if (ev.candidate) {
            addDoc(callerCandidatesRef, ev.candidate.toJSON()).catch(() => {});
          }
        };

        const offerDesc = await pc.createOffer();
        await pc.setLocalDescription(offerDesc);

        await updateDoc(doc(db, 'calls', call.callId), {
          offer: { type: offerDesc.type, sdp: offerDesc.sdp || '' },
          updatedAt: new Date().toISOString(),
        }).catch(() => {});

        unsubDoc = onSnapshot(doc(db, 'calls', call.callId), async (snap) => {
          const data = snap.data() as CallSession | undefined;
          if (data?.answer && !answerSetRef.current && pc.signalingState !== 'closed') {
            answerSetRef.current = true;
            await pc.setRemoteDescription(
              new RTCSessionDescription({ type: data.answer.type as RTCSdpType, sdp: data.answer.sdp })
            ).catch(() => {});
          }
        });

        unsubAnswerCand = onSnapshot(
          collection(db, 'calls', call.callId, 'calleeCandidates'),
          (snapshot) => {
            snapshot.docChanges().forEach((change) => {
              if (change.type === 'added') {
                pc.addIceCandidate(new RTCIceCandidate(change.doc.data())).catch(() => {});
              }
            });
          }
        );
      } catch (err: any) {
        setMediaError(err?.message || 'Microphone/Camera permission is needed for live calls.');
      }
    };

    startCaller();

    return () => {
      unsubAnswerCand?.();
      unsubDoc?.();
      cleanupMedia();
    };
  }, [call?.callId, isCaller]);

  // Callee accepts incoming call
  const handleAcceptCall = async () => {
    if (!liveCall) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: liveCall.callType === 'video',
      });
      localStreamRef.current = stream;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }

      const pc = new RTCPeerConnection(RTC_CONFIG);
      pcRef.current = pc;

      stream.getTracks().forEach((track) => pc.addTrack(track, stream));

      pc.ontrack = (event) => {
        const remoteStream = event.streams[0];
        if (remoteVideoRef.current) remoteVideoRef.current.srcObject = remoteStream;
        if (remoteAudioRef.current) remoteAudioRef.current.srcObject = remoteStream;
      };

      const calleeCandidatesRef = collection(db, 'calls', liveCall.callId, 'calleeCandidates');
      pc.onicecandidate = (ev) => {
        if (ev.candidate) {
          addDoc(calleeCandidatesRef, ev.candidate.toJSON()).catch(() => {});
        }
      };

      if (liveCall.offer) {
        await pc.setRemoteDescription(
          new RTCSessionDescription({ type: liveCall.offer.type as RTCSdpType, sdp: liveCall.offer.sdp })
        );
        const answerDesc = await pc.createAnswer();
        await pc.setLocalDescription(answerDesc);

        await updateDoc(doc(db, 'calls', liveCall.callId), {
          answer: { type: answerDesc.type, sdp: answerDesc.sdp || '' },
          status: 'active',
          updatedAt: new Date().toISOString(),
        });
      } else {
        await updateDoc(doc(db, 'calls', liveCall.callId), {
          status: 'active',
          updatedAt: new Date().toISOString(),
        });
      }

      onSnapshot(collection(db, 'calls', liveCall.callId, 'callerCandidates'), (snapshot) => {
        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added') {
            pc.addIceCandidate(new RTCIceCandidate(change.doc.data())).catch(() => {});
          }
        });
      });
    } catch (err: any) {
      setMediaError(err?.message || 'Could not access microphone/camera.');
      await updateDoc(doc(db, 'calls', liveCall.callId), {
        status: 'active',
        updatedAt: new Date().toISOString(),
      }).catch(() => {});
    }
  };

  const handleEndCall = async (nextStatus: 'ended' | 'declined' = 'ended') => {
    if (liveCall) {
      await updateDoc(doc(db, 'calls', liveCall.callId), {
        status: nextStatus,
        updatedAt: new Date().toISOString(),
      }).catch(() => {});
    }
    cleanupMedia();
    onClose();
  };

  const toggleMute = () => {
    const next = !micMuted;
    setMicMuted(next);
    localStreamRef.current?.getAudioTracks().forEach((tr) => {
      tr.enabled = !next;
    });
  };

  const toggleCam = () => {
    const next = !cameraOff;
    setCameraOff(next);
    localStreamRef.current?.getVideoTracks().forEach((tr) => {
      tr.enabled = !next;
    });
  };

  if (!call || !liveCall) return null;

  const peerName = isCaller ? liveCall.calleeDisplayName : liveCall.callerDisplayName;
  const peerPhoto = isCaller ? liveCall.calleePhotoURL : liveCall.callerPhotoURL;
  const peerUsername = isCaller ? liveCall.calleeUsername : liveCall.callerUsername;

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60).toString().padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex flex-col items-center justify-between p-6 text-white animate-in fade-in duration-200">
      <audio ref={remoteAudioRef} autoPlay className="hidden" />

      {/* Top Info */}
      <div className="w-full max-w-md flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#B09EFC]">
          {isVideo ? <Video className="w-4 h-4" /> : <Phone className="w-4 h-4" />}
          <span>{isVideo ? 'Video Call' : 'Audio Call'}</span>
        </div>
        <button
          onClick={() => handleEndCall('ended')}
          className="p-2 rounded-full bg-white/10 hover:bg-white/20"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Center Video or Avatar Stage */}
      <div className="flex-1 w-full max-w-md flex flex-col items-center justify-center relative my-4">
        {isVideo ? (
          <div className="relative w-full h-full max-h-[540px] rounded-3xl overflow-hidden bg-slate-900 border border-white/10 flex items-center justify-center">
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />
            {/* Local PiP Video */}
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className="absolute bottom-3 right-3 w-28 h-36 rounded-2xl object-cover border-2 border-[#7560DF] shadow-xl bg-black"
            />
            {liveCall.status !== 'active' && (
              <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-center p-4">
                <img
                  src={peerPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${peerUsername}`}
                  alt={peerName}
                  className="w-24 h-24 rounded-full object-cover ring-4 ring-[#7560DF] mb-3 animate-pulse"
                />
                <h3 className="text-xl font-extrabold">{peerName}</h3>
                <p className="text-xs text-white/70 mt-1">
                  {liveCall.status === 'ringing'
                    ? isCaller
                      ? 'Ringing...'
                      : 'Incoming Video Call...'
                    : liveCall.status}
                </p>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center text-center space-y-3">
            <div className="relative">
              <img
                src={peerPhoto || `https://api.dicebear.com/7.x/bottts/svg?seed=${peerUsername}`}
                alt={peerName}
                className={`w-28 h-28 rounded-full object-cover ring-4 ring-[#7560DF] ${
                  liveCall.status === 'ringing' ? 'animate-pulse' : ''
                }`}
              />
            </div>
            <h3 className="text-2xl font-extrabold">{peerName}</h3>
            <p className="text-xs text-[#B09EFC]">@{peerUsername}</p>
            <p className="text-sm font-mono text-white/80">
              {liveCall.status === 'active'
                ? formatDuration(elapsedSec)
                : liveCall.status === 'ringing'
                ? isCaller
                  ? 'Calling...'
                  : 'Incoming Audio Call...'
                : liveCall.status}
            </p>
          </div>
        )}

        {mediaError && (
          <div className="mt-3 px-4 py-2 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-200 text-xs text-center max-w-sm">
            {mediaError}
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="flex items-center justify-center gap-4 pb-4">
        {!isCaller && liveCall.status === 'ringing' ? (
          <>
            <button
              onClick={() => handleEndCall('declined')}
              className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg"
              title="Decline"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
            <button
              onClick={handleAcceptCall}
              className="p-4 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg animate-bounce"
              title="Accept"
            >
              {isVideo ? <Video className="w-6 h-6" /> : <Phone className="w-6 h-6" />}
            </button>
          </>
        ) : (
          <>
            <button
              onClick={toggleMute}
              className={`p-4 rounded-full transition-colors ${
                micMuted ? 'bg-rose-500/30 text-rose-300' : 'bg-white/15 hover:bg-white/25'
              }`}
              title={micMuted ? 'Unmute' : 'Mute'}
            >
              {micMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {isVideo && (
              <button
                onClick={toggleCam}
                className={`p-4 rounded-full transition-colors ${
                  cameraOff ? 'bg-rose-500/30 text-rose-300' : 'bg-white/15 hover:bg-white/25'
                }`}
                title={cameraOff ? 'Camera On' : 'Camera Off'}
              >
                {cameraOff ? <VideoOff className="w-5 h-5" /> : <Video className="w-5 h-5" />}
              </button>
            )}

            <button
              onClick={() => handleEndCall('ended')}
              className="p-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-lg"
              title="End Call"
            >
              <PhoneOff className="w-6 h-6" />
            </button>
          </>
        )}
      </div>
    </div>
  );
};
