import React, { useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../lib/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { ChatRoom, ChatMessage, UserProfile } from '../../types';
import { createAppNotification } from '../../lib/socialHelpers';
import {
  X,
  Users,
  Search,
  Check,
  Globe,
  Loader2,
  Sparkles
} from 'lucide-react';

interface CreateGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onGroupCreated: (groupRoom: ChatRoom) => void;
}

export const CreateGroupModal: React.FC<CreateGroupModalProps> = ({
  isOpen,
  onClose,
  onGroupCreated
}) => {
  const { currentUser, userProfile, allUsers } = useAuth();
  const [groupName, setGroupName] = useState('');
  const [groupDescription, setGroupDescription] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const otherUsers = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return allUsers
      .filter((u) => u.userId !== currentUser?.uid)
      .filter((u) => {
        if (!q) return true;
        return (
          u.username.toLowerCase().includes(q) ||
          u.displayName.toLowerCase().includes(q)
        );
      });
  }, [allUsers, currentUser, searchQuery]);

  if (!isOpen) return null;

  const toggleMember = (userId: string) => {
    setSelectedUserIds((prev) =>
      prev.includes(userId)
        ? prev.filter((id) => id !== userId)
        : [...prev, userId]
    );
  };

  const handleCreateGroup = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser || !userProfile) return;
    if (!groupName.trim()) {
      setErrorMsg('Please enter a group name.');
      return;
    }

    setErrorMsg(null);
    setSubmitting(true);

    try {
      const now = new Date().toISOString();
      const groupId = `group_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
      const participantIds = Array.from(new Set([currentUser.uid, ...selectedUserIds]));

      const participants: Record<string, { userId: string; username: string; displayName: string; photoURL?: string }> = {
        [userProfile.userId]: {
          userId: userProfile.userId,
          username: userProfile.username,
          displayName: userProfile.displayName,
          photoURL: userProfile.photoURL
        }
      };

      selectedUserIds.forEach((uid) => {
        const u = allUsers.find((usr: UserProfile) => usr.userId === uid);
        if (u) {
          participants[uid] = {
            userId: u.userId,
            username: u.username,
            displayName: u.displayName,
            photoURL: u.photoURL
          };
        }
      });

      const welcomeText = `${userProfile.displayName} created "${groupName.trim()}"`;

      const unreadCounts: Record<string, number> = { [currentUser.uid]: 0 };
      selectedUserIds.forEach((uid) => {
        unreadCounts[uid] = 1;
      });

      const groupRoom: ChatRoom = {
        chatId: groupId,
        participantIds,
        participants,
        isGroup: true,
        groupName: groupName.trim(),
        groupDescription: groupDescription.trim(),
        createdBy: currentUser.uid,
        adminIds: [currentUser.uid],
        postingLocked: false,
        isPublic: true,
        lastMessage: welcomeText,
        lastMessageTime: now,
        lastSenderId: currentUser.uid,
        unreadCounts,
        updatedAt: now
      };

      await setDoc(doc(db, 'chats', groupId), groupRoom);

      const welcomeMsgId = `msg_welcome_${Date.now()}`;
      const welcomeMsg: ChatMessage = {
        messageId: welcomeMsgId,
        chatId: groupId,
        senderId: userProfile.userId,
        senderUsername: userProfile.username,
        senderDisplayName: userProfile.displayName,
        senderPhotoURL: userProfile.photoURL,
        receiverId: groupId,
        type: 'text',
        text: `Welcome to ${groupName.trim()}! Say hello to the group.`,
        status: 'sent',
        createdAt: now
      };

      await setDoc(doc(db, 'chats', groupId, 'messages', welcomeMsgId), welcomeMsg);

      // Notify invited members
      await Promise.all(
        selectedUserIds.map((uid) =>
          createAppNotification({
            recipientId: uid,
            actor: userProfile,
            type: 'group',
            chatId: groupId,
            text: `invited you to group "${groupName.trim()}"`,
          })
        )
      );

      // Reset form & open created group
      setGroupName('');
      setGroupDescription('');
      setSelectedUserIds([]);
      setSearchQuery('');
      onGroupCreated(groupRoom);
    } catch (err: any) {
      console.error('Failed to create group:', err);
      setErrorMsg(err?.message || 'Could not create group. Please check your connection and try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-[#16132b] w-full max-w-md rounded-3xl shadow-2xl border border-slate-200/80 dark:border-purple-950/60 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-100 dark:border-purple-950/40 flex items-center justify-between bg-gradient-to-r from-[#7560DF]/10 to-transparent">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-[#7560DF] text-white flex items-center justify-center shadow-md shadow-[#7560DF]/25">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                Create Group Chat
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Talk together in real time with friends
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-purple-950/40 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleCreateGroup} className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* Group Name */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Group Name *
            </label>
            <input
              type="text"
              required
              maxLength={80}
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              placeholder="e.g. Addis Friends, Family Group..."
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
            />
          </div>

          {/* Group Description */}
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
              Description (Optional)
            </label>
            <input
              type="text"
              maxLength={200}
              value={groupDescription}
              onChange={(e) => setGroupDescription(e.target.value)}
              placeholder="What is this group about?"
              className="w-full px-4 py-2.5 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-sm text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
            />
          </div>

          {/* Public Facebook-Style Group Notice (No Private Groups) */}
          <div className="p-3 rounded-2xl bg-emerald-50/70 dark:bg-emerald-950/25 border border-emerald-200/80 dark:border-emerald-900/40 flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-900 dark:text-white">
                Public Group (Facebook-style)
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Anyone on Ethio Chat can see and join. Everyone can post unless locked by Owner.
              </p>
            </div>
          </div>

          {/* Select Members */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                Add Members ({selectedUserIds.length} selected)
              </label>
              <span className="text-[11px] text-[#7560DF] font-semibold">
                You are included automatically
              </span>
            </div>

            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search users by name or @username..."
                className="w-full pl-9 pr-4 py-2 rounded-2xl bg-slate-50 dark:bg-[#201c38] border border-slate-200 dark:border-purple-900/50 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-[#7560DF]"
              />
            </div>

            <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1">
              {otherUsers.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">
                  {allUsers.length <= 1
                    ? 'No other users registered yet — create a Public group so friends can join when they sign up!'
                    : 'No matching users found.'}
                </p>
              ) : (
                otherUsers.map((u) => {
                  const isSelected = selectedUserIds.includes(u.userId);
                  return (
                    <button
                      key={u.userId}
                      type="button"
                      onClick={() => toggleMember(u.userId)}
                      className={`w-full p-2.5 rounded-2xl border flex items-center justify-between gap-3 transition-all text-left ${
                        isSelected
                          ? 'border-[#7560DF] bg-[#7560DF]/10'
                          : 'border-slate-200/80 dark:border-purple-950/50 hover:bg-slate-50 dark:hover:bg-purple-950/20'
                      }`}
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <img
                          src={u.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.username}`}
                          alt={u.displayName}
                          className="w-9 h-9 rounded-full object-cover shrink-0"
                        />
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                            {u.displayName}
                          </p>
                          <p className="text-[11px] text-slate-400 truncate">
                            @{u.username}
                          </p>
                        </div>
                      </div>
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                          isSelected
                            ? 'bg-[#7560DF] text-white'
                            : 'border-2 border-slate-300 dark:border-purple-800'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/40 text-rose-700 dark:text-rose-300 text-xs">
              {errorMsg}
            </div>
          )}

          {/* Submit */}
          <button
            type="submit"
            disabled={submitting || !groupName.trim()}
            className="w-full py-3 rounded-2xl bg-[#7560DF] hover:bg-[#624ec7] text-white font-bold text-sm shadow-md shadow-[#7560DF]/25 disabled:opacity-50 transition-all flex items-center justify-center gap-2"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Creating Group...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Create Group & Start Chatting</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
